//! Exports of a source read in place, a chunk at a time: each chunk is put in the output's
//! coordinate system and written before the next is read, so a layer of any size is exported in
//! the memory of a chunk (and of what its format's writer keeps: a FlatGeobuf's index entries,
//! SQLite's page cache). Desktop only: the writers write files, which the web app hands over as
//! downloads instead.

use std::path::Path;

use crate::io::{CsvWriter, GeoJsonWriter, PROJECTED_FORMATS, check_projected, project_features, write_atomic_with};
use crate::raster::Crs;
use crate::source::FeatureSource;
use crate::{DataError, Dataset, Feature, GeometryType, Result};

/// The feature storage one chunk of an export holds.
const CHUNK_BYTES: usize = 32 << 20;

/// The formats exported a chunk at a time, by extension. The others (a Shapefile, whose field
/// widths come from a pass over the data; KML, KMZ, GPX) are written from a whole layer.
pub const STREAMED: [&str; 7] = ["geojson", "json", "csv", "fgb", "gpkg", "parquet", "geoparquet"];

/// Whether an export to extension `ext` can be written a chunk at a time (never in the web app).
pub fn streams(ext: &str) -> bool {
    !cfg!(target_arch = "wasm32") && STREAMED.contains(&ext.to_ascii_lowercase().as_str())
}

/// What an export wrote.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Exported {
    /// Features written.
    pub written: usize,
    /// Features the format couldn't hold (a FlatGeobuf holds only features with geometry).
    pub left_out: usize,
}

/// Writes every feature of `src` to `path` in the format of its extension, in `crs` (see
/// [`crate::io::write_path_in`], whose files these are), a chunk at a time. `layer` gives the
/// layer's name, fields and geometry type; its features aren't read. The file is written
/// beside `path` and moved into place once whole, so a failed export leaves nothing behind; a
/// GeoPackage, as ever, must be a new file.
pub fn write_source_in(src: &dyn FeatureSource, layer: &Dataset, path: &Path, crs: Crs) -> Result<Exported> {
    write_chunks_in(src, layer, path, crs, CHUNK_BYTES)
}

/// [`write_source_in`], `bytes` of features a chunk.
fn write_chunks_in(src: &dyn FeatureSource, layer: &Dataset, path: &Path, crs: Crs, bytes: usize) -> Result<Exported> {
    let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
    if !streams(&ext) {
        return Err(DataError::Unsupported(format!(".{ext} written a chunk at a time")));
    }
    if !src.visits_chunks() {
        return Err(DataError::Unsupported("a source that can't be read a chunk at a time".into()));
    }
    if crs != Crs::LonLat {
        if !PROJECTED_FORMATS.contains(&ext.as_str()) {
            return Err(DataError::Unsupported(format!(".{ext} in {} (it holds longitude/latitude only)", crs.label())));
        }
        check_projected(&ext, crs)?;
    }
    // A layer that declares no geometry type takes its first geometry's, as a whole read does.
    let geometry_type = match layer.geometry_type {
        GeometryType::None => first_kind(src, bytes)?,
        t => t,
    };
    let t = if crs == Crs::LonLat { None } else { Some(crs.transformer().map_err(DataError::Format)?) };
    let mut total = 0usize;
    let mut feed = |add: &mut dyn FnMut(&[Feature]) -> Result<()>| -> Result<()> {
        // A GeoPackage export that starts again feeds the features again.
        total = 0;
        src.visit_chunks(None, bytes, &mut |mut chunk| {
            if let Some(t) = &t {
                project_features(&mut chunk, t, crs)?;
            }
            total = total.saturating_add(chunk.len());
            add(&chunk)
        })?;
        Ok(())
    };
    let left_out = match ext.as_str() {
        #[cfg(not(target_arch = "wasm32"))]
        "gpkg" => {
            crate::source::gpkg::write_features_in(&layer.name, geometry_type, &layer.fields, path, crs, &mut feed)?;
            0
        }
        #[cfg(target_arch = "wasm32")]
        "gpkg" => return Err(DataError::Unsupported("GeoPackage in the browser".into())),
        "geojson" | "json" => write_atomic_with(path, |out| {
            let mut w = GeoJsonWriter::new(out, &layer.name, &layer.fields)?;
            feed(&mut |features| w.write(features))?;
            w.finish()?;
            Ok::<_, DataError>(0)
        })?,
        "csv" => write_atomic_with(path, |out| {
            let mut w = CsvWriter::new(out, &layer.fields, geometry_type)?;
            feed(&mut |features| w.write(features))?;
            w.finish()?;
            Ok::<_, DataError>(0)
        })?,
        "fgb" => write_atomic_with(path, |out| {
            crate::source::fgb::write_features(&layer.name, geometry_type, &layer.fields, crs, out, &mut feed)
        })?,
        _ => write_atomic_with(path, |out| {
            crate::source::parquet::write_features(geometry_type, &layer.fields, out, &mut feed)?;
            Ok::<_, DataError>(0)
        })?,
    };
    Ok(Exported { written: total.saturating_sub(left_out), left_out })
}

/// The kind of a source's first geometry, read up to it; `None` for a source without any (read
/// whole to be sure).
fn first_kind(src: &dyn FeatureSource, bytes: usize) -> Result<GeometryType> {
    let mut kind = GeometryType::None;
    let read = src.visit_chunks(None, bytes, &mut |chunk| match chunk.iter().find_map(|f| f.geometry.as_ref()) {
        Some(g) => {
            kind = g.kind();
            // Stops the traversal: nothing more is needed.
            Err(DataError::Format("found a geometry".into()))
        }
        None => Ok(()),
    });
    match read {
        Err(_) if kind != GeometryType::None => Ok(kind),
        Err(e) => Err(e),
        Ok(_) => Ok(kind),
    }
}

#[cfg(test)]
mod tests;
