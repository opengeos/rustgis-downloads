//! Symbols, renderers (single symbol, unique values, graduated colours, graduated symbols) and
//! labeling. A renderer maps each feature to a [`Symbol`] and describes its legend.

use std::collections::BTreeMap;

use rustgis_data::{Dataset, FieldType, GeometryType};
use serde::{Deserialize, Serialize};

use crate::color::{Ramp, Rgba};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Marker {
    #[default]
    Circle,
    Square,
    Triangle,
    Diamond,
    Star,
}

impl Marker {
    pub const ALL: [Marker; 5] = [Marker::Circle, Marker::Square, Marker::Triangle, Marker::Diamond, Marker::Star];
    pub fn label(self) -> &'static str {
        match self {
            Marker::Circle => "Circle",
            Marker::Square => "Square",
            Marker::Triangle => "Triangle",
            Marker::Diamond => "Diamond",
            Marker::Star => "Star",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Serialize, Deserialize)]
pub struct Symbol {
    pub fill: Rgba,
    pub stroke: Rgba,
    /// Outline / line width in points.
    pub stroke_width: f32,
    /// Marker size in points.
    pub size: f32,
    pub marker: Marker,
}

/// Default palette for new layers (cycled by layer id).
const LAYER_COLORS: [[u8; 3]; 8] = [
    [0x4A, 0x90, 0xD9],
    [0xE0, 0x7B, 0x39],
    [0x5B, 0xB0, 0x6E],
    [0xC2, 0x55, 0x9B],
    [0xE6, 0xB8, 0x3A],
    [0x7D, 0x6B, 0xD1],
    [0x3C, 0xB1, 0xB8],
    [0xB9, 0x5F, 0x4A],
];

impl Symbol {
    pub fn default_for(g: GeometryType, seed: u32) -> Symbol {
        let c = LAYER_COLORS.get(seed as usize % LAYER_COLORS.len()).copied().unwrap_or([0x4A, 0x90, 0xD9]);
        let base = Rgba::rgb(c[0], c[1], c[2]);
        match g {
            GeometryType::Point => {
                Symbol { fill: base, stroke: Rgba::rgb(255, 255, 255), stroke_width: 1.0, size: 7.0, marker: Marker::Circle }
            }
            GeometryType::Polyline => Symbol { fill: base, stroke: base, stroke_width: 1.6, size: 0.0, marker: Marker::Circle },
            _ => Symbol { fill: base.with_alpha(170), stroke: base.shade(0.6), stroke_width: 0.7, size: 0.0, marker: Marker::Circle },
        }
    }

    pub fn with_fill(mut self, c: Rgba, g: GeometryType) -> Symbol {
        match g {
            GeometryType::Polyline => {
                self.fill = c;
                self.stroke = c;
            }
            GeometryType::Polygon => {
                self.fill = c.with_alpha(self.fill.a().max(150));
                self.stroke = c.shade(0.6);
            }
            _ => self.fill = c,
        }
        self
    }

    /// Ramp colours change hue, not a polygon's existing fill opacity (even below 150).
    fn with_ramp_fill(self, c: Rgba, g: GeometryType) -> Symbol {
        let mut out = self.with_fill(c, g);
        if g == GeometryType::Polygon {
            out.fill = c.with_alpha(self.fill.a());
        }
        out
    }
}

/// How a stroke's open ends are drawn.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum LineCap {
    #[default]
    Round,
    Butt,
    Square,
}

impl LineCap {
    pub const ALL: [LineCap; 3] = [LineCap::Round, LineCap::Butt, LineCap::Square];
    pub fn code(self) -> &'static str {
        match self {
            LineCap::Round => "round",
            LineCap::Butt => "butt",
            LineCap::Square => "square",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            LineCap::Round => "Round",
            LineCap::Butt => "Flat",
            LineCap::Square => "Square",
        }
    }
    pub fn from_code(s: &str) -> Option<LineCap> {
        let s = s.trim();
        if s.eq_ignore_ascii_case("flat") {
            return Some(LineCap::Butt);
        }
        LineCap::ALL.into_iter().find(|c| c.code().eq_ignore_ascii_case(s))
    }
}

/// How a stroke turns at a vertex.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum LineJoin {
    #[default]
    Round,
    Miter,
    Bevel,
}

impl LineJoin {
    pub const ALL: [LineJoin; 3] = [LineJoin::Round, LineJoin::Miter, LineJoin::Bevel];
    pub fn code(self) -> &'static str {
        match self {
            LineJoin::Round => "round",
            LineJoin::Miter => "miter",
            LineJoin::Bevel => "bevel",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            LineJoin::Round => "Round",
            LineJoin::Miter => "Miter",
            LineJoin::Bevel => "Bevel",
        }
    }
    pub fn from_code(s: &str) -> Option<LineJoin> {
        let s = s.trim();
        LineJoin::ALL.into_iter().find(|j| j.code().eq_ignore_ascii_case(s))
    }
}

/// The most strokes one line symbol stacks.
pub const MAX_STROKES: usize = 16;
/// The widest stroke and the farthest offset, in points.
pub const MAX_STROKE_WIDTH: f32 = 50.0;
pub const MAX_STROKE_OFFSET: f32 = 100.0;
/// The most steps a dash pattern has, and the longest step, in points.
pub const MAX_DASH_STEPS: usize = 8;
pub const MAX_DASH_STEP: f32 = 500.0;

/// A stroke's dash pattern: lengths in points, dash and gap in turn, starting with a dash (as
/// SVG's `stroke-dasharray`: an odd number of steps is repeated to make it even). Written to a
/// project as that list, `[4, 2]`. Built only through [`Dash::new`], so its steps are always
/// in range and add up to more than nothing.
#[derive(Clone, Copy, Debug, PartialEq, Serialize)]
#[serde(into = "Vec<f32>")]
pub struct Dash {
    steps: [f32; MAX_DASH_STEPS],
    len: u8,
}

impl Dash {
    /// The pattern of `steps` (at most [`MAX_DASH_STEPS`], each 0 to [`MAX_DASH_STEP`]), or
    /// `None` for none: no steps, a step that isn't a number from 0 to [`MAX_DASH_STEP`], too
    /// many, or all of them 0.
    pub fn new(steps: &[f32]) -> Option<Dash> {
        let ok = |v: &f32| v.is_finite() && (0.0..=MAX_DASH_STEP).contains(v);
        if steps.is_empty() || steps.len() > MAX_DASH_STEPS || !steps.iter().all(ok) || steps.iter().sum::<f32>() <= 0.0 {
            return None;
        }
        let mut d = Dash { steps: [0.0; MAX_DASH_STEPS], len: u8::try_from(steps.len()).ok()? };
        d.steps.get_mut(..steps.len())?.copy_from_slice(steps);
        Some(d)
    }

    /// Its steps, as given.
    pub fn steps(&self) -> &[f32] {
        self.steps.get(..usize::from(self.len)).unwrap_or(&[])
    }

    /// Its steps made even (an odd number twice over), as a renderer takes them.
    pub fn even_steps(&self) -> Vec<f32> {
        let s = self.steps();
        if s.len().is_multiple_of(2) { s.to_vec() } else { s.iter().chain(s).copied().collect() }
    }

    /// One round of the pattern, in points.
    pub fn period(&self) -> f32 {
        self.even_steps().iter().sum()
    }
}

/// Reads a stroke's pattern from a project, brought into range: at most [`MAX_DASH_STEPS`] steps,
/// each clamped to 0 to [`MAX_DASH_STEP`] (one too large for a number, infinite, the longest);
/// one left without length is `None`, solid (a project file is hostile input).
fn de_dash<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Option<Dash>, D::Error> {
    let Some(v) = Option::<Vec<f32>>::deserialize(d)? else { return Ok(None) };
    let steps: Vec<f32> = v.iter().take(MAX_DASH_STEPS).map(|x| if x.is_nan() { 0.0 } else { x.clamp(0.0, MAX_DASH_STEP) }).collect();
    Ok(Dash::new(&steps))
}

impl From<Dash> for Vec<f32> {
    fn from(d: Dash) -> Vec<f32> {
        d.steps().to_vec()
    }
}

/// One stroke of a line layer's stacked symbol (`Layer::line_strokes`). Widths and offsets are
/// in points, so they keep their size on screen at every scale; the geometry is left as it is.
#[derive(Clone, Copy, Debug, PartialEq, Serialize, Deserialize)]
pub struct LineStroke {
    /// The colour; `None` takes the feature's line colour from the renderer, so the strokes
    /// follow Unique Values and Graduated Colors classes.
    #[serde(default)]
    pub color: Option<Rgba>,
    /// The width in points; `None` takes the feature's line width from the renderer.
    #[serde(default)]
    pub width: Option<f32>,
    /// The sideways shift in points: positive to the right of the line's direction (the order
    /// of its vertices), negative to the left. Two copies of a line drawn in opposite
    /// directions land on opposite sides.
    #[serde(default)]
    pub offset: f32,
    #[serde(default)]
    pub cap: LineCap,
    #[serde(default)]
    pub join: LineJoin,
    /// When the layer draws its strokes in levels (`Layer::stroke_levels`), the level this one
    /// draws at: every feature's strokes of one level go down before any of the next, so casings
    /// join under the cores. `None` is its place in the stack, the bottom one 0.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub level: Option<u8>,
    /// Dashed: the pattern along the line, in points; `None` is a solid line.
    #[serde(default, skip_serializing_if = "Option::is_none", deserialize_with = "de_dash")]
    pub dash: Option<Dash>,
}

impl Default for LineStroke {
    fn default() -> Self {
        LineStroke { color: None, width: None, offset: 0.0, cap: LineCap::Round, join: LineJoin::Round, level: None, dash: None }
    }
}

impl LineStroke {
    /// The level it draws at as the `i`th stroke of its stack (see [`LineStroke::level`]).
    pub fn level_at(&self, i: usize) -> u8 {
        self.level.unwrap_or_else(|| u8::try_from(i).unwrap_or(u8::MAX))
    }

    /// The colour and width it draws a feature whose renderer symbol is `s` with.
    pub fn resolve(&self, s: &Symbol) -> (Rgba, f32) {
        (self.color.unwrap_or(s.stroke), self.width.unwrap_or(s.stroke_width))
    }

    /// Brought into range: finite, width 0 to [`MAX_STROKE_WIDTH`], offset within
    /// ±[`MAX_STROKE_OFFSET`].
    pub fn clamped(mut self) -> LineStroke {
        self.width = self.width.map(|w| if w.is_finite() { w.clamp(0.0, MAX_STROKE_WIDTH) } else { 1.0 });
        self.offset = if self.offset.is_finite() { self.offset.clamp(-MAX_STROKE_OFFSET, MAX_STROKE_OFFSET) } else { 0.0 };
        self
    }
}

/// Reads a layer's strokes as the command would leave them: at most [`MAX_STROKES`], each
/// [`LineStroke::clamped`]. A project file is hostile input, and every stroke is drawn per
/// feature per frame.
pub fn de_strokes<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Vec<LineStroke>, D::Error> {
    let mut v: Vec<LineStroke> = Vec::deserialize(d)?;
    v.truncate(MAX_STROKES);
    Ok(v.into_iter().map(LineStroke::clamped).collect())
}

/// Reads a renderer's per-class strokes as [`de_strokes`] reads a layer's: each class's at most
/// [`MAX_STROKES`], each [`LineStroke::clamped`]. A class left with none is dropped.
pub fn de_class_strokes<'de, D, K>(d: D) -> Result<BTreeMap<K, Vec<LineStroke>>, D::Error>
where
    D: serde::Deserializer<'de>,
    K: Deserialize<'de> + Ord,
{
    let m: BTreeMap<K, Vec<LineStroke>> = BTreeMap::deserialize(d)?;
    Ok(m.into_iter()
        .filter(|(_, v)| !v.is_empty())
        .map(|(k, mut v)| {
            v.truncate(MAX_STROKES);
            (k, v.into_iter().map(LineStroke::clamped).collect())
        })
        .collect())
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum ClassMethod {
    #[default]
    NaturalBreaks,
    EqualInterval,
    Quantile,
    /// Class widths that grow by one ratio, for values that pile up at the low end.
    GeometricInterval,
    /// Classes one standard deviation wide about the mean.
    StandardDeviation,
    /// Bounds typed by hand, kept as they are (see [`Renderer::graduated_manual`]).
    Manual,
}

impl ClassMethod {
    pub const ALL: [ClassMethod; 6] = [
        ClassMethod::NaturalBreaks,
        ClassMethod::EqualInterval,
        ClassMethod::Quantile,
        ClassMethod::GeometricInterval,
        ClassMethod::StandardDeviation,
        ClassMethod::Manual,
    ];
    pub fn label(self) -> &'static str {
        match self {
            ClassMethod::NaturalBreaks => "Natural Breaks (Jenks)",
            ClassMethod::EqualInterval => "Equal Interval",
            ClassMethod::Quantile => "Quantile",
            ClassMethod::GeometricInterval => "Geometric Interval",
            ClassMethod::StandardDeviation => "Standard Deviation",
            ClassMethod::Manual => "Manual",
        }
    }
    pub fn from_name(s: &str) -> Option<ClassMethod> {
        let s = s.trim().to_ascii_lowercase();
        Some(match s.as_str() {
            "naturalbreaks" | "natural_breaks" | "jenks" | "natural breaks" => ClassMethod::NaturalBreaks,
            "equalinterval" | "equal_interval" | "equal interval" => ClassMethod::EqualInterval,
            "quantile" => ClassMethod::Quantile,
            "geometricinterval" | "geometric_interval" | "geometric interval" | "geometric" => ClassMethod::GeometricInterval,
            "standarddeviation" | "standard_deviation" | "standard deviation" | "stddev" => ClassMethod::StandardDeviation,
            "manual" => ClassMethod::Manual,
            _ => return None,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum Renderer {
    Single(Symbol),
    Unique {
        field: String,
        classes: Vec<(String, Symbol)>,
        other: Symbol,
        ramp: Ramp,
        /// Legend labels set by hand, by class value; a class without one shows its value. A value
        /// listed twice (a style import can do that) shares one label, as it shares one drawn
        /// symbol: features take their value's first class (`symbol_for`).
        #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
        class_labels: BTreeMap<String, String>,
        /// The legend label of `other`, when set by hand (otherwise `<all other values>`).
        #[serde(default, skip_serializing_if = "Option::is_none")]
        other_label: Option<String>,
        /// A line layer's stacked strokes for one class, by class value: drawn for that class's
        /// features instead of the layer's `line_strokes`. A class without its own takes the layer's.
        #[serde(default, skip_serializing_if = "BTreeMap::is_empty", deserialize_with = "de_class_strokes")]
        class_strokes: BTreeMap<String, Vec<LineStroke>>,
        /// The stacked strokes of `other`; empty takes the layer's.
        #[serde(default, skip_serializing_if = "Vec::is_empty", deserialize_with = "de_strokes")]
        other_strokes: Vec<LineStroke>,
    },
    /// Upper bounds of each class (ascending) and one symbol per class.
    Graduated {
        field: String,
        breaks: Vec<f64>,
        symbols: Vec<Symbol>,
        ramp: Ramp,
        method: ClassMethod,
        min: f64,
        /// Legend labels set by hand, by class index (0 is the lowest class); a class without one
        /// shows its range.
        #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
        class_labels: BTreeMap<usize, String>,
        /// A line layer's stacked strokes for one class, by class index, as Unique Values'.
        #[serde(default, skip_serializing_if = "BTreeMap::is_empty", deserialize_with = "de_class_strokes")]
        class_strokes: BTreeMap<usize, Vec<LineStroke>>,
    },
    /// Marker size grows with the value.
    Proportional {
        field: String,
        base: Symbol,
        min_size: f32,
        max_size: f32,
        min: f64,
        max: f64,
    },
}

/// The legend label of a Unique Values renderer's fallback class.
pub const OTHER_VALUES: &str = "<all other values>";

/// One legend row.
#[derive(Clone, Debug, PartialEq)]
pub struct LegendEntry {
    pub label: String,
    pub symbol: Symbol,
    /// The Unique Values fallback row (`<all other values>`), told apart from a class whatever
    /// its label: a legend can leave it out without touching a class that bears the same name.
    pub fallback: bool,
}

/// Most unique-value classes created automatically.
pub const MAX_UNIQUE: usize = 64;

/// The colour of a new Unique Values renderer's `<all other values>` class.
pub const OTHER_FILL: Rgba = Rgba::rgb(0xB0, 0xB0, 0xB0);

/// The longest legend label set by hand, in characters.
pub const MAX_LABEL: usize = 200;

/// One class of a Unique Values or Graduated Colors renderer, as a command names it.
#[derive(Clone, Debug, PartialEq)]
pub enum ClassRef {
    /// A Unique Values class, by its value.
    Value(String),
    /// A Graduated Colors class, by index (0 is the lowest).
    Index(usize),
    /// The Unique Values fallback, `<all other values>`.
    Other,
}

/// The class a feature falls in ([`Renderer::class_of`]): a place in the classes, or Unique
/// Values' `<all other values>`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Slot {
    Class(usize),
    Other,
}

fn no_class(i: usize, n: usize) -> String {
    format!("no class {i}: this renderer has {n} (0 to {})", n.saturating_sub(1))
}

/// Why a class reference doesn't fit the renderer, as [`Renderer::set_class_style`] says it.
fn class_mismatch(r: &Renderer) -> String {
    match r {
        Renderer::Unique { .. } => "Unique Values classes are named by their value, not by number".into(),
        Renderer::Graduated { .. } => "Graduated Colors classes are numbered from 0, the lowest".into(),
        _ => "only Unique Values and Graduated Colors have classes to style".into(),
    }
}

/// What [`Renderer::set_class_style`] changes in a class; `None` leaves that part as it is.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ClassStyle {
    pub color: Option<Rgba>,
    /// For RGB-only command input, keep the polygon's legacy translucency instead of setting alpha.
    pub preserve_fill_alpha: bool,
    pub outline: Option<Rgba>,
    /// `Some("")` clears a label set by hand, so the class shows its value or range again.
    pub label: Option<String>,
}

impl Renderer {
    pub fn kind_label(&self) -> &'static str {
        match self {
            Renderer::Single(_) => "Single Symbol",
            Renderer::Unique { .. } => "Unique Values",
            Renderer::Graduated { .. } => "Graduated Colors",
            Renderer::Proportional { .. } => "Proportional Symbols",
        }
    }

    pub fn field(&self) -> Option<&str> {
        match self {
            Renderer::Single(_) => None,
            Renderer::Unique { field, .. } | Renderer::Graduated { field, .. } | Renderer::Proportional { field, .. } => Some(field),
        }
    }

    /// The first symbol (the single symbol, or a representative).
    pub fn base_symbol(&self) -> Symbol {
        match self {
            Renderer::Single(s) => *s,
            Renderer::Unique { other, classes, .. } => classes.first().map(|c| c.1).unwrap_or(*other),
            Renderer::Graduated { symbols, .. } => symbols.last().copied().unwrap_or(Symbol::default_for(GeometryType::Polygon, 0)),
            Renderer::Proportional { base, .. } => *base,
        }
    }

    /// Builds a unique-values renderer on `field`, from the rows `rows` keeps (a row past its end
    /// counts, so `&[]` keeps them all).
    pub fn unique(ds: &Dataset, rows: &[bool], field: &str, ramp: Ramp, base: Symbol) -> Result<Renderer, String> {
        let fi = ds.field_index(field).ok_or_else(|| format!("no field named '{field}'"))?;
        let vals = ds.unique_values(fi, rows, MAX_UNIQUE);
        let n = vals.len();
        let classes = vals.into_iter().enumerate().map(|(k, v)| (v, base.with_ramp_fill(ramp.pick(k, n), ds.geometry_type))).collect();
        let other = base.with_ramp_fill(OTHER_FILL, ds.geometry_type);
        Ok(Renderer::Unique {
            field: ds.fields.get(fi).map(|f| f.name.clone()).unwrap_or_default(),
            classes,
            other,
            ramp,
            class_labels: BTreeMap::new(),
            other_label: None,
            class_strokes: BTreeMap::new(),
            other_strokes: Vec::new(),
        })
    }

    /// Builds a graduated-colours renderer on a numeric `field`, classing the rows `rows` keeps (a
    /// row past its end counts, so `&[]` keeps them all).
    pub fn graduated(
        ds: &Dataset,
        rows: &[bool],
        field: &str,
        classes: usize,
        method: ClassMethod,
        ramp: Ramp,
        base: Symbol,
    ) -> Result<Renderer, String> {
        let k = classes.clamp(1, 12);
        Self::graduated_by(ds, rows, field, method, ramp, base, |vals| Ok(class_breaks(vals, k, method)))
    }

    /// Builds a graduated-colours renderer on the class bounds typed by hand: the classes' upper
    /// bounds, sorted and each once, closed by the field's largest value when they stop short of
    /// it, so every feature has a class. At most 12 classes.
    pub fn graduated_manual(
        ds: &Dataset,
        rows: &[bool],
        field: &str,
        breaks: &[f64],
        ramp: Ramp,
        base: Symbol,
    ) -> Result<Renderer, String> {
        Self::graduated_by(ds, rows, field, ClassMethod::Manual, ramp, base, |vals| {
            let mut b: Vec<f64> = breaks.iter().copied().filter(|v| v.is_finite()).collect();
            if b.is_empty() {
                return Err("manual breaks need at least one number".into());
            }
            b.sort_by(|a, b| a.total_cmp(b));
            b.dedup();
            if let Some(&hi) = vals.last()
                && b.last().is_some_and(|&l| l < hi)
            {
                b.push(hi);
            }
            if b.len() > 12 {
                return Err(format!("{} classes; Graduated Colors takes at most 12", b.len()));
            }
            Ok(b)
        })
    }

    /// A graduated renderer on `field`, with the bounds `breaks` works out from the field's sorted
    /// values.
    fn graduated_by(
        ds: &Dataset,
        rows: &[bool],
        field: &str,
        method: ClassMethod,
        ramp: Ramp,
        base: Symbol,
        breaks: impl FnOnce(&[f64]) -> Result<Vec<f64>, String>,
    ) -> Result<Renderer, String> {
        let fi = ds.field_index(field).ok_or_else(|| format!("no field named '{field}'"))?;
        if !ds.fields.get(fi).is_some_and(|f| f.ty.is_numeric()) {
            return Err(format!("'{field}' is not a numeric field"));
        }
        let mut vals: Vec<f64> = ds.kept_features(rows).filter_map(|f| f.attrs.get(fi).and_then(|v| v.as_f64())).collect();
        if vals.is_empty() {
            return Err(format!("'{field}' has no numeric values"));
        }
        vals.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let breaks = breaks(&vals)?;
        let n = breaks.len();
        let symbols = (0..n).map(|i| base.with_ramp_fill(ramp.pick(i, n), ds.geometry_type)).collect();
        let min = vals.first().copied().unwrap_or(0.0);
        Ok(Renderer::Graduated {
            field: ds.fields.get(fi).map(|f| f.name.clone()).unwrap_or_default(),
            breaks,
            symbols,
            ramp,
            method,
            min,
            class_labels: BTreeMap::new(),
            class_strokes: BTreeMap::new(),
        })
    }

    /// Builds a proportional-symbols renderer on a numeric `field`, sized over the rows `rows` keeps
    /// (a row past its end counts, so `&[]` keeps them all).
    pub fn proportional(ds: &Dataset, rows: &[bool], field: &str, base: Symbol) -> Result<Renderer, String> {
        let fi = ds.field_index(field).ok_or_else(|| format!("no field named '{field}'"))?;
        if !ds.fields.get(fi).is_some_and(|f| f.ty.is_numeric()) {
            return Err(format!("'{field}' is not a numeric field"));
        }
        let (min, max) = ds.numeric_range(fi, rows).ok_or_else(|| format!("'{field}' has no numeric values"))?;
        let mut base = base;
        if base.size == 0.0 {
            base.size = 6.0;
        }
        Ok(Renderer::Proportional {
            field: ds.fields.get(fi).map(|f| f.name.clone()).unwrap_or_default(),
            base,
            min_size: 4.0,
            max_size: 28.0,
            min,
            max,
        })
    }

    /// The class a feature row falls in: a Unique Values class's place in `classes` (its value's
    /// first class) or `<all other values>`, a Graduated Colors class's index; `None` for the other
    /// renderers, and for a Graduated Colors row without a number.
    fn class_of(&self, ds: &Dataset, row: usize) -> Option<Slot> {
        match self {
            Renderer::Unique { field, classes, .. } => {
                let Some(fi) = ds.field_index(field) else { return Some(Slot::Other) };
                // Text compares as it is; other values as they print.
                let printed;
                let v = match ds.value(row, fi) {
                    rustgis_data::Value::Text(t) => t.as_str(),
                    v => {
                        printed = v.to_string();
                        printed.as_str()
                    }
                };
                Some(classes.iter().position(|(k, _)| k == v).map_or(Slot::Other, Slot::Class))
            }
            Renderer::Graduated { field, breaks, .. } => {
                let v = ds.field_index(field).and_then(|fi| ds.value(row, fi).as_f64())?;
                Some(Slot::Class(breaks.iter().position(|b| v <= *b).unwrap_or(breaks.len().saturating_sub(1))))
            }
            Renderer::Single(_) | Renderer::Proportional { .. } => None,
        }
    }

    /// The stacked strokes a line feature row's class has of its own (`class_strokes`), or `None`
    /// when its class has none (the layer's `line_strokes` apply).
    pub fn strokes_for(&self, ds: &Dataset, row: usize) -> Option<&[LineStroke]> {
        self.strokes_in(self.class_of(ds, row))
    }

    /// The symbol a feature row draws with ([`Renderer::symbol_for`]) and its class's own stacked
    /// strokes ([`Renderer::strokes_for`]), the feature classed once for both.
    pub fn style_for(&self, ds: &Dataset, row: usize) -> (Symbol, Option<&[LineStroke]>) {
        let slot = self.class_of(ds, row);
        (self.symbol_in(ds, row, slot), self.strokes_in(slot))
    }

    fn strokes_in(&self, slot: Option<Slot>) -> Option<&[LineStroke]> {
        let strokes = match (self, slot?) {
            (Renderer::Unique { classes, class_strokes, .. }, Slot::Class(i)) => class_strokes.get(&classes.get(i)?.0)?,
            (Renderer::Unique { other_strokes, .. }, Slot::Other) => other_strokes,
            (Renderer::Graduated { class_strokes, .. }, Slot::Class(i)) => class_strokes.get(&i)?,
            _ => return None,
        };
        (!strokes.is_empty()).then_some(strokes.as_slice())
    }

    /// Whether any class has stacked strokes of its own.
    pub fn has_class_strokes(&self) -> bool {
        match self {
            Renderer::Unique { class_strokes, other_strokes, .. } => !class_strokes.is_empty() || !other_strokes.is_empty(),
            Renderer::Graduated { class_strokes, .. } => !class_strokes.is_empty(),
            Renderer::Single(_) | Renderer::Proportional { .. } => false,
        }
    }

    /// One class's own stacked strokes (empty when it takes the layer's).
    pub fn class_strokes(&self, class: &ClassRef) -> Result<&[LineStroke], String> {
        let none: &[LineStroke] = &[];
        match (self, class) {
            (Renderer::Unique { classes, class_strokes, .. }, ClassRef::Value(v)) => {
                if !classes.iter().any(|(k, _)| k == v) {
                    return Err(format!("no class with the value '{v}'"));
                }
                Ok(class_strokes.get(v).map_or(none, Vec::as_slice))
            }
            (Renderer::Unique { other_strokes, .. }, ClassRef::Other) => Ok(other_strokes),
            (Renderer::Graduated { symbols, class_strokes, .. }, ClassRef::Index(i)) => {
                if *i >= symbols.len() {
                    return Err(no_class(*i, symbols.len()));
                }
                Ok(class_strokes.get(i).map_or(none, Vec::as_slice))
            }
            _ => Err(class_mismatch(self)),
        }
    }

    /// Sets one class's own stacked strokes, at most [`MAX_STROKES`], each brought into range;
    /// none goes back to the layer's.
    pub fn set_class_strokes(&mut self, class: &ClassRef, strokes: Vec<LineStroke>) -> Result<(), String> {
        if strokes.len() > MAX_STROKES {
            return Err(format!("at most {MAX_STROKES} strokes"));
        }
        let strokes: Vec<LineStroke> = strokes.into_iter().map(LineStroke::clamped).collect();
        match (&mut *self, class) {
            (Renderer::Unique { classes, class_strokes, .. }, ClassRef::Value(v)) => {
                if !classes.iter().any(|(k, _)| k == v) {
                    return Err(format!("no class with the value '{v}'"));
                }
                if strokes.is_empty() {
                    class_strokes.remove(v);
                } else {
                    class_strokes.insert(v.clone(), strokes);
                }
            }
            (Renderer::Unique { other_strokes, .. }, ClassRef::Other) => *other_strokes = strokes,
            (Renderer::Graduated { symbols, class_strokes, .. }, ClassRef::Index(i)) => {
                if *i >= symbols.len() {
                    return Err(no_class(*i, symbols.len()));
                }
                if strokes.is_empty() {
                    class_strokes.remove(i);
                } else {
                    class_strokes.insert(*i, strokes);
                }
            }
            _ => return Err(class_mismatch(self)),
        }
        Ok(())
    }

    /// Symbol for a feature row.
    pub fn symbol_for(&self, ds: &Dataset, row: usize) -> Symbol {
        self.symbol_in(ds, row, self.class_of(ds, row))
    }

    /// The symbol for a feature row in class `slot` ([`Renderer::class_of`]).
    fn symbol_in(&self, ds: &Dataset, row: usize, slot: Option<Slot>) -> Symbol {
        match self {
            Renderer::Single(s) => *s,
            Renderer::Unique { classes, other, .. } => match slot {
                Some(Slot::Class(i)) => classes.get(i).map_or(*other, |c| c.1),
                _ => *other,
            },
            Renderer::Graduated { symbols, .. } => {
                let fallback = symbols.first().copied().unwrap_or(Symbol::default_for(ds.geometry_type, 0));
                let Some(Slot::Class(i)) = slot else {
                    return Symbol { fill: Rgba::new(0xC8, 0xC8, 0xC8, 140), ..fallback };
                };
                symbols.get(i).copied().unwrap_or(fallback)
            }
            Renderer::Proportional { field, base, min_size, max_size, min, max } => {
                let Some(v) = ds.field_index(field).and_then(|fi| ds.value(row, fi).as_f64()) else { return *base };
                let t = if max > min { ((v - min) / (max - min)).clamp(0.0, 1.0) } else { 0.5 };
                // Area-proportional (Flannery-free square root scaling).
                Symbol { size: min_size + (max_size - min_size) * t.sqrt() as f32, ..*base }
            }
        }
    }

    /// The legend for the features `rows` keeps (a row past its end counts, so `&[]` keeps them
    /// all): a Unique Values class only when some kept feature has it, and `<all other values>`
    /// only when some kept feature matches no class and its symbol is not fully transparent (#207).
    /// The classes may come from a style file or from before a definition query changed, so they
    /// can name values no kept feature has. The other renderers list their classes as they are.
    pub fn legend_for(&self, ds: &Dataset, rows: &[bool]) -> Vec<LegendEntry> {
        let Renderer::Unique { field, classes, other, class_labels, other_label, .. } = self else { return self.legend() };
        // A value matches its first class, as in `symbol_for`.
        let mut index: std::collections::HashMap<&str, usize> = std::collections::HashMap::new();
        for (i, (k, _)) in classes.iter().enumerate() {
            index.entry(k.as_str()).or_insert(i);
        }
        let fi = ds.field_index(field);
        let mut used = vec![false; classes.len()];
        let mut other_used = false;
        // Distinct classes still unseen: once every class and "other" are in, the rest can't add any.
        let mut unseen = index.len() + 1;
        // One buffer for every value's text, rather than a string per feature.
        let mut text = String::new();
        for r in (0..ds.features.len()).filter(|r| rows.get(*r).copied().unwrap_or(true)) {
            let class = fi.and_then(|fi| {
                use std::fmt::Write;
                text.clear();
                write!(text, "{}", ds.value(r, fi)).ok()?;
                index.get(text.as_str()).copied()
            });
            let seen = match class.and_then(|i| used.get_mut(i)) {
                Some(u) => std::mem::replace(u, true),
                None => std::mem::replace(&mut other_used, true),
            };
            if !seen {
                unseen -= 1;
                if unseen == 0 {
                    break;
                }
            }
        }
        let mut v: Vec<LegendEntry> = classes
            .iter()
            .zip(&used)
            .filter(|(_, u)| **u)
            .map(|((k, s), _)| LegendEntry { label: unique_label(class_labels, k), symbol: *s, fallback: false })
            .collect();
        v.sort_by_cached_key(|e| e.label.to_lowercase());
        // A fully transparent fallback draws nothing, so it has nothing to stand for in a legend.
        // Lines draw with their stroke only.
        let visible = other.stroke.a() > 0 || (ds.geometry_type != GeometryType::Polyline && other.fill.a() > 0);
        if other_used && visible {
            v.push(LegendEntry { label: other_label.clone().unwrap_or_else(|| OTHER_VALUES.into()), symbol: *other, fallback: true });
        }
        v
    }

    /// The order `legend()` lists the Unique Values classes in: their indices in `classes`,
    /// sorted by label without regard to case (a stable sort, so a repeated value keeps its first
    /// class first). Empty for the other renderers, whose legend follows their classes.
    pub fn class_order(&self) -> Vec<usize> {
        let Renderer::Unique { classes, class_labels, .. } = self else { return Vec::new() };
        let mut order: Vec<usize> = (0..classes.len()).collect();
        order.sort_by_cached_key(|i| classes.get(*i).map(|(k, _)| unique_label(class_labels, k).to_lowercase()));
        order
    }

    pub fn legend(&self) -> Vec<LegendEntry> {
        match self {
            Renderer::Single(_) => Vec::new(),
            Renderer::Unique { classes, other, class_labels, other_label, .. } => {
                // Keep symbols attached to their sorted labels and the fallback at the end.
                let mut v: Vec<LegendEntry> = self
                    .class_order()
                    .into_iter()
                    .filter_map(|i| classes.get(i))
                    .map(|(k, s)| LegendEntry { label: unique_label(class_labels, k), symbol: *s, fallback: false })
                    .collect();
                v.push(LegendEntry { label: other_label.clone().unwrap_or_else(|| OTHER_VALUES.into()), symbol: *other, fallback: true });
                v
            }
            Renderer::Graduated { breaks, symbols, min, class_labels, .. } => {
                let mut lo = *min;
                breaks
                    .iter()
                    .zip(symbols)
                    .enumerate()
                    .map(|(i, (b, s))| {
                        let label = class_labels.get(&i).cloned().unwrap_or_else(|| range_label(lo, *b));
                        lo = *b;
                        LegendEntry { label, symbol: *s, fallback: false }
                    })
                    .collect()
            }
            Renderer::Proportional { base, min_size, max_size, min, max, .. } => vec![
                LegendEntry { label: fmt_num(*min), symbol: Symbol { size: *min_size, ..*base }, fallback: false },
                LegendEntry {
                    label: fmt_num((min + max) / 2.0),
                    symbol: Symbol { size: min_size + (max_size - min_size) * 0.707, ..*base },
                    fallback: false,
                },
                LegendEntry { label: fmt_num(*max), symbol: Symbol { size: *max_size, ..*base }, fallback: false },
            ],
        }
    }

    /// Recolours every class from a ramp, preserving each polygon fill's opacity.
    pub fn apply_ramp(&mut self, ramp: Ramp, g: GeometryType) {
        match self {
            Renderer::Unique { classes, ramp: r, .. } => {
                let n = classes.len();
                for (k, c) in classes.iter_mut().enumerate() {
                    c.1 = c.1.with_ramp_fill(ramp.pick(k, n), g);
                }
                *r = ramp;
            }
            Renderer::Graduated { symbols, ramp: r, .. } => {
                let n = symbols.len();
                for (k, s) in symbols.iter_mut().enumerate() {
                    *s = s.with_ramp_fill(ramp.pick(k, n), g);
                }
                *r = ramp;
            }
            _ => {}
        }
    }

    /// Sets one class's colour, outline colour and legend label (#314). A line class takes the
    /// colour as its line colour; a polygon class gets a matching outline unless `outline` names
    /// one. Colours include their alpha unless `preserve_fill_alpha` requests the polygon's
    /// legacy translucency for RGB-only input. Returns the class's legend row as it now is.
    pub fn set_class_style(&mut self, class: &ClassRef, style: &ClassStyle, g: GeometryType) -> Result<LegendEntry, String> {
        let label = style.label.as_deref().map(normalize_label);
        let restyle = |s: &mut Symbol| {
            if let Some(c) = style.color {
                *s = s.with_fill(c, g);
                if g == GeometryType::Polygon && !style.preserve_fill_alpha {
                    s.fill = c;
                }
            }
            if let Some(c) = style.outline {
                s.stroke = c;
            }
        };
        // The class's row in `legend()`, which lists the classes and then `other`. Unique Values
        // rows are sorted by label, so that class's row is built here rather than looked up.
        let row = match (&mut *self, class) {
            (Renderer::Unique { classes, class_labels, .. }, ClassRef::Value(v)) => {
                let i = classes.iter().position(|(k, _)| k == v).ok_or_else(|| format!("no class with the value '{v}'"))?;
                if let Some((k, s)) = classes.get_mut(i) {
                    restyle(s);
                    match label {
                        // Empty, or the value itself: the class shows its value, with no label of its own.
                        Some(t) if t.is_empty() || t == *k => {
                            class_labels.remove(k.as_str());
                        }
                        Some(t) => {
                            class_labels.insert(k.clone(), t);
                        }
                        None => {}
                    }
                }
                return classes
                    .get(i)
                    .map(|(k, s)| LegendEntry { label: unique_label(class_labels, k), symbol: *s, fallback: false })
                    .ok_or_else(|| "the class has no legend row".into());
            }
            (Renderer::Unique { classes, other, other_label, .. }, ClassRef::Other) => {
                restyle(other);
                if let Some(t) = label {
                    *other_label = (!t.is_empty() && t != OTHER_VALUES).then_some(t);
                }
                classes.len()
            }
            (Renderer::Graduated { symbols, class_labels, breaks, min, .. }, ClassRef::Index(i)) => {
                // The range the class shows when it has no label of its own.
                let lo = if *i == 0 { Some(*min) } else { breaks.get(*i - 1).copied() };
                let range = lo.zip(breaks.get(*i).copied()).map(|(lo, hi)| range_label(lo, hi));
                let n = symbols.len();
                let s = symbols.get_mut(*i).ok_or_else(|| format!("no class {i}: this renderer has {n} (0 to {})", n.saturating_sub(1)))?;
                restyle(s);
                match label {
                    Some(t) if t.is_empty() || Some(&t) == range.as_ref() => {
                        class_labels.remove(i);
                    }
                    Some(t) => {
                        class_labels.insert(*i, t);
                    }
                    None => {}
                }
                *i
            }
            (Renderer::Unique { .. }, ClassRef::Index(_)) => {
                return Err("Unique Values classes are named by their value, not by number".into());
            }
            (Renderer::Graduated { .. }, _) => return Err("Graduated Colors classes are numbered from 0, the lowest".into()),
            _ => return Err("only Unique Values and Graduated Colors have classes to style".into()),
        };
        self.legend().into_iter().nth(row).ok_or_else(|| "the class has no legend row".into())
    }

    /// Carries hand-made class edits over from `old` when the symbology is applied again (#314).
    /// On the same field, a class that is still there keeps its legend label (a Graduated Colors
    /// class keeps its edits only while the ranges are the same: they belong to a range). With the
    /// same colour scheme too, it keeps the colour and outline set by hand: those that aren't what
    /// the scheme gave it at its place in `old` (see [`carry_class`]). The other classes take the
    /// new scheme's colours at their new places, on the new base symbol. A different scheme
    /// recolours every class (picking a scheme is asking for its colours); a different field
    /// starts fresh.
    pub fn carry_edits_from(&mut self, old: &Renderer, g: GeometryType) {
        match (self, old) {
            (
                Renderer::Unique { field, classes, other, ramp, class_labels, other_label, class_strokes, other_strokes },
                Renderer::Unique {
                    field: of,
                    classes: oc,
                    other: oo,
                    ramp: or,
                    class_labels: ol,
                    other_label: ool,
                    class_strokes: ost,
                    other_strokes: oos,
                },
            ) if field == of => {
                let same_scheme = ramp == or;
                let n = oc.len();
                // Strokes are drawn by hand, as labels are: a class keeps them whatever the scheme.
                other_strokes.clone_from(oos);
                for (k, s) in classes.iter_mut() {
                    if let Some(t) = ol.get(k.as_str()) {
                        class_labels.insert(k.clone(), t.clone());
                    }
                    if let Some(st) = ost.get(k.as_str()) {
                        class_strokes.insert(k.clone(), st.clone());
                    }
                    if same_scheme
                        && let Some(j) = oc.iter().position(|(ok, _)| ok == k)
                        && let Some((_, os)) = oc.get(j)
                    {
                        *s = carry_class(*s, os, or.pick(j, n), g);
                    }
                }
                other_label.clone_from(ool);
                if same_scheme {
                    *other = carry_class(*other, oo, OTHER_FILL, g);
                }
            }
            (
                Renderer::Graduated { field, breaks, symbols, ramp, min, class_labels, class_strokes, .. },
                Renderer::Graduated { field: of, breaks: ob, symbols: os, ramp: or, min: om, class_labels: ol, class_strokes: ost, .. },
            ) if field == of => {
                // A Graduated Colors edit belongs to a range: it stays only while the ranges do.
                if breaks != ob || min != om {
                    return;
                }
                class_labels.clone_from(ol);
                class_strokes.clone_from(ost);
                if ramp == or && symbols.len() == os.len() {
                    let n = os.len();
                    for (i, (s, o)) in symbols.iter_mut().zip(os).enumerate() {
                        *s = carry_class(*s, o, or.pick(i, n), g);
                    }
                }
            }
            _ => {}
        }
    }

    /// Applies `f` to every symbol.
    pub fn map_symbols(&mut self, f: impl Fn(&mut Symbol)) {
        match self {
            Renderer::Single(s) => f(s),
            Renderer::Unique { classes, other, .. } => {
                classes.iter_mut().for_each(|c| f(&mut c.1));
                f(other);
            }
            Renderer::Graduated { symbols, .. } => symbols.iter_mut().for_each(f),
            Renderer::Proportional { base, .. } => f(base),
        }
    }
}

/// `new` with the hand-made parts of `old`, a class whose scheme colour was `scheme`: the fill
/// when it isn't that colour, and the outline when it isn't the one [`Symbol::with_fill`] derives
/// (a polygon's shaded fill, a line's own colour; for points, the new base symbol's outline).
/// Polygon hue edits compare without alpha because ramps keep polygon opacity. That opacity
/// carries over independently, including alpha-only edits; point and line colours compare whole.
/// Outlines compare whole.
fn carry_class(new: Symbol, old: &Symbol, scheme: Rgba, g: GeometryType) -> Symbol {
    let rgb = |c: Rgba| (c.r(), c.g(), c.b());
    let mut s = new;
    let edited = if g == GeometryType::Polygon { rgb(old.fill) != rgb(scheme) } else { old.fill != scheme };
    if edited {
        let c = if g == GeometryType::Polygon { Rgba::rgb(old.fill.r(), old.fill.g(), old.fill.b()) } else { old.fill };
        s = s.with_fill(c, g);
    }
    if g == GeometryType::Polygon {
        s.fill = s.fill.with_alpha(old.fill.a());
    }
    let derived = match g {
        GeometryType::Polygon => Rgba::rgb(old.fill.r(), old.fill.g(), old.fill.b()).shade(0.6),
        GeometryType::Polyline => old.fill,
        _ => new.stroke,
    };
    if old.stroke != derived {
        s.stroke = old.stroke;
    }
    s
}

/// A legend label as [`Renderer::set_class_style`] keeps it: one line (control characters such as
/// line breaks become spaces), trimmed, cut to [`MAX_LABEL`] characters and trimmed again (a cut
/// can end in a space). An editor compares its text this way to tell whether it changed.
pub fn normalize_label(t: &str) -> String {
    let t: String = t.chars().map(|c| if c.is_control() { ' ' } else { c }).collect();
    t.trim().chars().take(MAX_LABEL).collect::<String>().trim_end().to_string()
}

/// A Unique Values class's legend label: the one set by hand, or its value.
fn unique_label(class_labels: &BTreeMap<String, String>, value: &str) -> String {
    class_labels.get(value).cloned().unwrap_or_else(|| value.to_string())
}

/// A Graduated Colors class's legend label when it has none of its own: its range.
fn range_label(lo: f64, hi: f64) -> String {
    format!("{} – {}", fmt_num(lo), fmt_num(hi))
}

/// Compact number formatting for legends: 1.2M, 35K, 0.42.
pub fn fmt_num(v: f64) -> String {
    let a = v.abs();
    if (a / 1e5).round() >= 10_000.0 {
        format!("{:.1}B", v / 1e9)
    } else if (a / 1e3).round() >= 1_000.0 {
        format!("{:.1}M", v / 1e6)
    } else if a.round() >= 1e4 {
        format!("{:.0}K", v / 1e3)
    } else if (a * 100.0).round() >= 10_000.0 || v.fract() == 0.0 {
        format!("{v:.0}")
    } else {
        format!("{v:.2}")
    }
}

/// Upper class bounds for sorted values.
pub fn class_breaks(sorted: &[f64], k: usize, method: ClassMethod) -> Vec<f64> {
    let n = sorted.len();
    let (Some(&lo), Some(&hi)) = (sorted.first(), sorted.last()) else { return Vec::new() };
    if k <= 1 || hi <= lo {
        return vec![hi];
    }
    let mut b = match method {
        // Manual bounds are typed, not worked out: asked to work them out, it starts from equal intervals.
        ClassMethod::EqualInterval | ClassMethod::Manual => (1..=k).map(|i| lo + (hi - lo) * i as f64 / k as f64).collect::<Vec<_>>(),
        ClassMethod::Quantile => (1..=k).map(|i| sorted.get(((n * i) / k).saturating_sub(1).min(n - 1)).copied().unwrap_or(hi)).collect(),
        ClassMethod::NaturalBreaks => jenks(sorted, k),
        ClassMethod::GeometricInterval => {
            // Positive values: each bound is the one before times (hi / lo)^(1/k), worked out on
            // logarithms. Values from zero or below are taken as if the minimum sat at a hundredth
            // of the range, which makes the ratio 101^(1/k); each bound is then a share of the way
            // from lo to hi. Neither adds large values, so the bounds stay finite and in order.
            let range = hi - lo;
            (1..=k)
                .map(|i| {
                    let f = i as f64 / k as f64;
                    let v = if lo > 0.0 {
                        (lo.ln() + (hi.ln() - lo.ln()) * f).exp()
                    } else {
                        let t = (101f64.powf(f) - 1.0) / 100.0;
                        if range.is_finite() { lo + range * t } else { lo * (1.0 - t) + hi * t }
                    };
                    v.clamp(lo, hi)
                })
                .collect()
        }
        ClassMethod::StandardDeviation => {
            // On values scaled by the largest magnitude, so the squares can't overflow.
            let s = lo.abs().max(hi.abs());
            let mean_s = sorted.iter().map(|v| v / s).sum::<f64>() / n as f64;
            let mean = mean_s * s;
            let sd = s * (sorted.iter().map(|v| (v / s - mean_s).powi(2)).sum::<f64>() / n as f64).sqrt();
            // k − 1 inner bounds one deviation apart, centred on the mean. A bound with no value
            // above the one before it is dropped, so no class is empty.
            let inner = (1..k).map(|i| mean + sd * (i as f64 - k as f64 / 2.0)).filter(|&v| v > lo && v < hi);
            let mut b = Vec::new();
            let mut below = 0;
            for v in inner.chain(std::iter::once(hi)) {
                let upto = sorted.partition_point(|x| *x <= v);
                if upto > below {
                    b.push(v);
                    below = upto;
                }
            }
            b
        }
    };
    // Only bounds that are the same value: any tolerance merges distinct values somewhere (tiny
    // ones under an absolute one, large ones under a relative one). Repeated bounds come from
    // repeated values (quantiles, Jenks), so they are equal exactly.
    b.dedup();
    if let Some(l) = b.last_mut() {
        *l = hi;
    }
    b
}

/// Jenks natural breaks (Fisher's dynamic programming), on a sample of at most 1000 values.
fn jenks(sorted: &[f64], k: usize) -> Vec<f64> {
    let data: Vec<f64> = if sorted.len() > 1000 {
        (0..1000).filter_map(|i| sorted.get(i * sorted.len() / 1000)).copied().collect()
    } else {
        sorted.to_vec()
    };
    let n = data.len();
    let k = k.min(n);
    if k < 2 {
        return vec![data.last().copied().unwrap_or(0.0)];
    }
    // lower[i][j]: first index of class j for data[0..=i]; var[i][j]: within-class variance.
    let mut lower = vec![vec![0usize; k + 1]; n + 1];
    let mut var = vec![vec![f64::INFINITY; k + 1]; n + 1];
    for j in 1..=k {
        lower[1][j] = 1;
        var[1][j] = 0.0;
    }
    for l in 2..=n {
        let (mut s1, mut s2, mut w) = (0.0, 0.0, 0.0);
        let mut v = 0.0;
        for m in 1..=l {
            let i3 = l - m + 1;
            let val = data[i3 - 1];
            s2 += val * val;
            s1 += val;
            w += 1.0;
            v = s2 - (s1 * s1) / w;
            let i4 = i3 - 1;
            if i4 != 0 {
                for j in 2..=k {
                    if var[l][j] >= v + var[i4][j - 1] {
                        lower[l][j] = i3;
                        var[l][j] = v + var[i4][j - 1];
                    }
                }
            }
        }
        lower[l][1] = 1;
        var[l][1] = v;
    }
    let mut breaks = vec![0.0; k];
    breaks[k - 1] = data[n - 1];
    let mut kk = n;
    for j in (2..=k).rev() {
        let id = lower[kk][j].saturating_sub(2);
        breaks[j - 2] = data[id];
        kk = lower[kk][j].saturating_sub(1).max(1);
    }
    breaks
}

/// The label sizes `labels.style` accepts, in points (Style › Text Symbol).
pub const LABEL_SIZE: std::ops::RangeInclusive<f64> = 4.0..=72.0;

/// The most label classes a layer keeps besides its Default class.
pub const MAX_LABEL_CLASSES: usize = 64;

/// The name the Default class goes by until it is renamed.
pub const DEFAULT_LABEL_CLASS: &str = "Default";

/// The longest label class name kept (characters).
pub const MAX_LABEL_CLASS_NAME: usize = 100;

/// A label class name as it is kept: trimmed and cut to [`MAX_LABEL_CLASS_NAME`] characters (not
/// ending in the space it was cut at). Empty when there's no name.
pub fn label_class_name(name: &str) -> String {
    let name: String = name.trim().chars().take(MAX_LABEL_CLASS_NAME).collect();
    name.trim_end().to_string()
}

/// Label settings for a layer: on or off, and its label classes (#618). As in ArcGIS Pro, each
/// class labels every feature its SQL clause matches, so a feature two classes match gets a label
/// from each (#732); `classes` come first and `default` last, the order their labels are placed
/// in when they compete for room. Saved as before: the Default class's settings sit beside `enabled`
/// and the other classes are listed only when there are any, so a project without them keeps
/// its old form.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(from = "LabelingFile")]
pub struct Labeling {
    pub enabled: bool,
    #[serde(flatten)]
    pub default: LabelClass,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub classes: Vec<LabelClass>,
}

/// A layer's labels as a file holds them, read into what the commands would leave (see `From`).
#[derive(Deserialize)]
struct LabelingFile {
    enabled: bool,
    #[serde(flatten)]
    default: LabelClass,
    #[serde(default)]
    classes: Vec<LabelClass>,
}

impl From<LabelingFile> for Labeling {
    /// A project file is hostile input, and every feature drawn is matched against the classes:
    /// names are kept as the commands keep them ([`label_class_name`]; Default's is "Default"
    /// when it has none), and at most [`MAX_LABEL_CLASSES`] classes, each named, by a name no
    /// class before it nor Default has (ASCII case aside). The others are dropped, since commands
    /// and annotation classes (`"CLASS" = 'name'`) tell classes apart by name.
    fn from(mut f: LabelingFile) -> Self {
        f.default.name = label_class_name(&f.default.name);
        if f.default.name.is_empty() {
            f.default.name = DEFAULT_LABEL_CLASS.into();
        }
        let mut classes: Vec<LabelClass> = Vec::new();
        for mut c in f.classes {
            if classes.len() >= MAX_LABEL_CLASSES {
                break;
            }
            c.name = label_class_name(&c.name);
            let same = |n: &str| n.eq_ignore_ascii_case(&c.name);
            if !c.name.is_empty() && !same(&f.default.name) && !classes.iter().any(|o| same(&o.name)) {
                classes.push(c);
            }
        }
        Labeling { enabled: f.enabled, default: f.default, classes }
    }
}

/// One class of a layer's labels: the features it labels, the field it labels them with, its text
/// symbol, placement and visibility range.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct LabelClass {
    #[serde(default = "default_class_name", skip_serializing_if = "is_default_class_name")]
    pub name: String,
    /// A hidden class labels none of its features (the other classes still label theirs).
    #[serde(default = "yes", skip_serializing_if = "is_yes")]
    pub visible: bool,
    /// The SQL `WHERE` clause choosing its features (the definition query's language); none, or
    /// blank, takes every feature. One that no longer reads (a field since removed) takes none.
    #[serde(default, rename = "where", skip_serializing_if = "Option::is_none")]
    pub where_: Option<String>,
    pub field: String,
    pub size: f32,
    pub color: Rgba,
    pub halo: bool,
    pub bold: bool,
    /// Labels draw only when zoomed in beyond 1:`min_scale`, if set.
    #[serde(default)]
    pub min_scale: Option<f64>,
    /// Labels draw only when zoomed out beyond 1:`max_scale`, if set.
    #[serde(default)]
    pub max_scale: Option<f64>,
    /// Labels draw only when the viewer is at least this far away (metres), if set.
    #[serde(default)]
    pub closest: Option<f64>,
    /// Labels draw only when the viewer is at most this far away (metres), if set.
    #[serde(default)]
    pub farthest: Option<f64>,
    /// Where a label sits relative to its feature.
    #[serde(default)]
    pub placement: LabelPlacement,
    /// Slanted (an italic face where the font has one).
    #[serde(default, skip_serializing_if = "std::ops::Not::not")]
    pub italic: bool,
    /// The installed font family the labels are drawn in, by name ("Liberation Sans Narrow"), as
    /// QGIS names a text format's; none is the label font. A machine without the family draws
    /// them in the label font too.
    #[serde(default, deserialize_with = "de_font", skip_serializing_if = "Option::is_none")]
    pub font: Option<String>,
}

/// The longest font family name kept (characters).
pub const MAX_FONT_NAME: usize = 128;

/// A label font's family name as it is kept: trimmed, at most [`MAX_FONT_NAME`] characters, and
/// none when blank.
pub fn font_name(name: &str) -> Option<String> {
    let name: String = name.trim().chars().filter(|c| !c.is_control()).take(MAX_FONT_NAME).collect();
    let name = name.trim();
    (!name.is_empty()).then(|| name.to_string())
}

/// A label class's font as a project has it, kept as [`font_name`] keeps it: a name, or none for
/// anything else (a number, a list), so a damaged font doesn't make the project unreadable.
fn de_font<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Option<String>, D::Error> {
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum Font {
        Name(String),
        Other(serde::de::IgnoredAny),
    }
    Ok(match Option::<Font>::deserialize(d)? {
        Some(Font::Name(n)) => font_name(&n),
        Some(Font::Other(_)) | None => None,
    })
}

fn default_class_name() -> String {
    DEFAULT_LABEL_CLASS.into()
}

fn is_default_class_name(n: &str) -> bool {
    n == DEFAULT_LABEL_CLASS
}

fn yes() -> bool {
    true
}

fn is_yes(b: &bool) -> bool {
    *b
}

/// Where labels sit relative to their feature's label point.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum LabelPlacement {
    /// Above points, centred on lines and polygons.
    #[default]
    Auto,
    Center,
    Above,
    Below,
    Left,
    Right,
    AboveRight,
    AboveLeft,
    BelowRight,
    BelowLeft,
    /// Along a line, straight, turned to its direction across the text, at its middle; points
    /// and polygons are labelled as `Auto`.
    Parallel,
    /// Along a line, each character turned with it where it bends, at its middle; points and
    /// polygons are labelled as `Auto`.
    Curved,
}

impl LabelPlacement {
    /// Whether a line is labelled along it ([`Parallel`](Self::Parallel) or
    /// [`Curved`](Self::Curved)).
    pub fn along_line(self) -> bool {
        matches!(self, LabelPlacement::Parallel | LabelPlacement::Curved)
    }

    pub const ALL: [LabelPlacement; 12] = [
        LabelPlacement::Auto,
        LabelPlacement::Center,
        LabelPlacement::Above,
        LabelPlacement::Below,
        LabelPlacement::Left,
        LabelPlacement::Right,
        LabelPlacement::AboveRight,
        LabelPlacement::AboveLeft,
        LabelPlacement::BelowRight,
        LabelPlacement::BelowLeft,
        LabelPlacement::Parallel,
        LabelPlacement::Curved,
    ];
    pub fn code(self) -> &'static str {
        match self {
            LabelPlacement::Auto => "auto",
            LabelPlacement::Center => "center",
            LabelPlacement::Above => "above",
            LabelPlacement::Below => "below",
            LabelPlacement::Left => "left",
            LabelPlacement::Right => "right",
            LabelPlacement::AboveRight => "aboveRight",
            LabelPlacement::AboveLeft => "aboveLeft",
            LabelPlacement::BelowRight => "belowRight",
            LabelPlacement::BelowLeft => "belowLeft",
            LabelPlacement::Parallel => "parallel",
            LabelPlacement::Curved => "curved",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            LabelPlacement::Auto => "Automatic",
            LabelPlacement::Center => "Centered",
            LabelPlacement::Above => "Above",
            LabelPlacement::Below => "Below",
            LabelPlacement::Left => "Left",
            LabelPlacement::Right => "Right",
            LabelPlacement::AboveRight => "Above Right",
            LabelPlacement::AboveLeft => "Above Left",
            LabelPlacement::BelowRight => "Below Right",
            LabelPlacement::BelowLeft => "Below Left",
            LabelPlacement::Parallel => "Parallel",
            LabelPlacement::Curved => "Curved",
        }
    }
    pub fn from_code(s: &str) -> Option<LabelPlacement> {
        LabelPlacement::ALL.into_iter().find(|p| p.code().eq_ignore_ascii_case(s.trim()))
    }
    /// The label centre's offset from the label point, in points, for a label `w` wide and `h`
    /// tall next to a marker of size `marker` (0 for lines and polygons).
    pub fn offset(self, w: f32, h: f32, marker: f32, is_point: bool) -> (f32, f32) {
        let gap = marker / 2.0 + 2.0;
        let (dx, dy) = (w / 2.0 + gap, h / 2.0 + gap);
        match self {
            LabelPlacement::Auto | LabelPlacement::Parallel | LabelPlacement::Curved if is_point => (0.0, -(marker / 2.0 + h * 0.6)),
            LabelPlacement::Auto | LabelPlacement::Center | LabelPlacement::Parallel | LabelPlacement::Curved => (0.0, 0.0),
            LabelPlacement::Above => (0.0, -dy),
            LabelPlacement::Below => (0.0, dy),
            LabelPlacement::Left => (-dx, 0.0),
            LabelPlacement::Right => (dx, 0.0),
            LabelPlacement::AboveRight => (dx, -dy),
            LabelPlacement::AboveLeft => (-dx, -dy),
            LabelPlacement::BelowRight => (dx, dy),
            LabelPlacement::BelowLeft => (-dx, dy),
        }
    }
}

impl LabelClass {
    /// The Default class: on the first text field that looks like a name.
    pub fn default_for(ds: &Dataset) -> LabelClass {
        let field = ds
            .fields
            .iter()
            .find(|f| f.ty == FieldType::Text && f.name.to_ascii_lowercase().contains("name"))
            .or_else(|| ds.fields.iter().find(|f| f.ty == FieldType::Text))
            .or_else(|| ds.fields.first())
            .map(|f| f.name.clone())
            .unwrap_or_default();
        LabelClass {
            name: default_class_name(),
            visible: true,
            where_: None,
            field,
            size: 10.0,
            color: Rgba::rgb(0x2B, 0x2B, 0x2B),
            halo: true,
            bold: false,
            min_scale: None,
            max_scale: None,
            closest: None,
            farthest: None,
            placement: LabelPlacement::Auto,
            italic: false,
            font: None,
        }
    }

    /// Whether labels draw at a scale denominator and viewing distance (metres).
    pub fn in_range(&self, scale: f64, distance: f64) -> bool {
        self.min_scale.is_none_or(|m| scale <= m)
            && self.max_scale.is_none_or(|m| scale >= m)
            && self.closest.is_none_or(|d| distance >= d)
            && self.farthest.is_none_or(|d| distance <= d)
    }

    /// Its clause, read against `ds`: `Some(None)` takes every feature, `Some(Some(e))` those
    /// matching `e`, and `None` (a clause that doesn't read) takes none.
    pub fn query(&self, ds: &Dataset) -> Option<Option<rustgis_data::query::Expr>> {
        match self.where_.as_deref().map(str::trim).filter(|w| !w.is_empty()) {
            None => Some(None),
            Some(w) => rustgis_data::query::parse(w, ds).ok().map(Some),
        }
    }
}

/// A label on the map, as (layer id, row, label class in `Labeling::in_order`): a feature has a
/// label for each class labelling it (#732).
pub type LabelKey = (u32, usize, usize);

/// A layer's label classes read against its data, in `Labeling::in_order`: every class whose
/// clause takes a row labels it.
pub struct LabelMatcher<'a> {
    classes: Vec<(&'a LabelClass, Option<Option<rustgis_data::query::Expr>>)>,
}

impl<'a> LabelMatcher<'a> {
    pub fn new(labels: &'a Labeling, ds: &Dataset) -> Self {
        LabelMatcher { classes: labels.in_order().map(|c| (c, c.query(ds))).collect() }
    }

    /// The classes whose clause takes `row`, each with its place in `Labeling::in_order`.
    pub fn classes_of(&self, ds: &Dataset, row: usize) -> impl Iterator<Item = (usize, &'a LabelClass)> {
        self.classes.iter().enumerate().filter_map(move |(i, (c, q))| match q {
            Some(None) => Some((i, *c)),
            Some(Some(e)) if rustgis_data::query::eval(e, ds, row) => Some((i, *c)),
            _ => None,
        })
    }
}

impl Labeling {
    /// The classes in the order a feature is matched: the listed ones, then Default. At most
    /// `MAX_LABEL_CLASSES` of them count (a project file is read with no more), also for a
    /// `Labeling` built in code, since every feature drawn is matched against them.
    pub fn in_order(&self) -> impl Iterator<Item = &LabelClass> {
        self.classes.iter().take(MAX_LABEL_CLASSES).chain(std::iter::once(&self.default))
    }

    /// The class named `name` (ASCII case aside), Default included.
    pub fn class(&self, name: &str) -> Option<&LabelClass> {
        self.in_order().find(|c| c.name.eq_ignore_ascii_case(name.trim()))
    }

    /// The class named `name` (ASCII case aside), Default included, to change.
    pub fn class_mut(&mut self, name: &str) -> Option<&mut LabelClass> {
        let name = name.trim();
        if self.default.name.eq_ignore_ascii_case(name) {
            return Some(&mut self.default);
        }
        self.classes.iter_mut().take(MAX_LABEL_CLASSES).find(|c| c.name.eq_ignore_ascii_case(name))
    }

    /// Turns the labels off and starts the Default class again on `ds`'s first name-like field
    /// (`LabelClass::default_for`), keeping its name, clause and visibility: its field was
    /// deleted. (A service refresh keeps Default's text symbol instead, and clears its field.)
    pub fn restart_default(&mut self, ds: &Dataset) {
        self.enabled = false;
        let old = std::mem::replace(&mut self.default, LabelClass::default_for(ds));
        (self.default.name, self.default.visible, self.default.where_) = (old.name, old.visible, old.where_);
    }

    /// Points every class on a field `ds` doesn't have at the Default class's field, or the first
    /// name-like one when Default's is gone too (a field deleted, a style from another layer, a
    /// service's fields changed). The class is kept, with its clause and text symbol.
    pub fn repoint_missing_fields(&mut self, ds: &Dataset) {
        // Default's field, or (it is gone too, cleared by a refresh) the first name-like one, so
        // a class isn't left on no field.
        let fallback = match ds.field_index(&self.default.field) {
            Some(_) => self.default.field.clone(),
            None => LabelClass::default_for(ds).field,
        };
        for c in self.classes.iter_mut().filter(|c| ds.field_index(&c.field).is_none()) {
            c.field.clone_from(&fallback);
        }
    }

    /// Off, on the first text field that looks like a name, with only its Default class.
    pub fn default_for(ds: &Dataset) -> Labeling {
        Labeling { enabled: false, default: LabelClass::default_for(ds), classes: Vec::new() }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rustgis_data::{Field, Value};

    /// Labels saved before label classes (#618) read as the Default class alone, and are written
    /// back the same, so older versions still read a project without classes.
    #[test]
    fn labels_without_classes_keep_their_saved_form() {
        let old = serde_json::json!({
            "enabled": true, "field": "name", "size": 9.0, "color": [10, 20, 30, 255], "halo": false, "bold": true,
            "min_scale": 500000.0, "max_scale": null, "closest": null, "farthest": null, "placement": "AboveRight"
        });
        let l: Labeling = serde_json::from_value(old.clone()).unwrap();
        assert!(l.enabled && l.classes.is_empty());
        assert_eq!((l.default.name.as_str(), l.default.visible, &l.default.where_), (DEFAULT_LABEL_CLASS, true, &None));
        assert_eq!((l.default.field.as_str(), l.default.size, l.default.placement), ("name", 9.0, LabelPlacement::AboveRight));
        assert_eq!(serde_json::to_value(&l).unwrap(), old);
        // With classes, they are listed after the Default class's settings, and read back.
        let mut with = l.clone();
        with.classes.push(LabelClass { name: "Capitals".into(), where_: Some("capital = 1".into()), visible: false, ..l.default.clone() });
        let v = serde_json::to_value(&with).unwrap();
        assert_eq!(v["field"], "name");
        assert_eq!(v["classes"][0]["where"], "capital = 1");
        assert_eq!(serde_json::from_value::<Labeling>(v).unwrap(), with);
    }

    /// A label font is kept by its family name, trimmed and bounded (a project file is hostile
    /// input); a blank one is the label font, and isn't written.
    #[test]
    fn a_label_font_is_kept_by_name() {
        let read = |font: serde_json::Value| {
            serde_json::from_value::<Labeling>(serde_json::json!({
                "enabled": true, "field": "name", "size": 9.0, "color": [0, 0, 0, 255], "halo": false, "bold": false, "font": font
            }))
            .unwrap()
        };
        let l = read("  Liberation Sans Narrow \n".into());
        assert_eq!(l.default.font.as_deref(), Some("Liberation Sans Narrow"));
        assert_eq!(serde_json::to_value(&l).unwrap()["font"], "Liberation Sans Narrow");
        // Not a name (a number, a list, an object): no font, and the rest of the labels still read.
        for blank in [
            serde_json::json!("  "),
            serde_json::Value::Null,
            serde_json::json!(7),
            serde_json::json!(["Arial"]),
            serde_json::json!({"a": 1}),
        ] {
            let l = read(blank);
            assert_eq!(l.default.font, None);
            assert!(serde_json::to_value(&l).unwrap().get("font").is_none());
        }
        assert_eq!(read("x".repeat(10_000).into()).default.font.map(|f| f.chars().count()), Some(MAX_FONT_NAME));
    }

    /// A project file is read with at most `MAX_LABEL_CLASSES` classes, and only that many count
    /// in a `Labeling` built with more. A class on
    /// a field the data doesn't have is pointed at Default's, and kept.
    #[test]
    fn classes_are_bounded_and_follow_missing_fields() {
        let ds = Dataset::new("t", GeometryType::Point, vec![Field::new("name", FieldType::Text)]);
        let mut l = Labeling::default_for(&ds);
        let class = |i: usize| LabelClass { name: format!("c{i}"), field: "gone".into(), ..LabelClass::default_for(&ds) };
        l.classes = (0..MAX_LABEL_CLASSES + 5).map(class).collect();
        // A project file listing more is read with the first ones.
        let read: Labeling = serde_json::from_value(serde_json::to_value(&l).unwrap()).unwrap();
        assert_eq!(read.classes.len(), MAX_LABEL_CLASSES);
        assert_eq!(read.classes.last().map(|c| c.name.clone()), Some(format!("c{}", MAX_LABEL_CLASSES - 1)));
        // And with one class to a name, as the commands keep them: none blank, nor named as one
        // before it or Default.
        let mut v = serde_json::to_value(Labeling::default_for(&ds)).unwrap();
        // A class saved without a name (its name is Default's, which is skipped) too.
        let named = |n: Option<&str>| {
            let mut c = serde_json::to_value(LabelClass::default_for(&ds)).unwrap();
            if let Some(n) = n {
                c["name"] = n.into();
            }
            c
        };
        let long = format!("{} tail", "b".repeat(99));
        let names = [Some(" A "), Some("a"), Some("  "), Some("default"), None, Some(long.as_str())];
        v["classes"] = names.into_iter().map(named).collect();
        let read: Labeling = serde_json::from_value(v.clone()).unwrap();
        let b = "b".repeat(99);
        assert_eq!(read.classes.iter().map(|c| c.name.as_str()).collect::<Vec<_>>(), ["A", b.as_str()]);
        // Default's name is kept the same way, and is Default's when blank.
        v["name"] = "   ".into();
        let read: Labeling = serde_json::from_value(v.clone()).unwrap();
        assert_eq!(read.default.name, DEFAULT_LABEL_CLASS);
        v["name"] = " Rest ".into();
        assert_eq!(serde_json::from_value::<Labeling>(v).unwrap().default.name, "Rest");
        assert_eq!(l.in_order().count(), MAX_LABEL_CLASSES + 1, "the counted classes, then Default");
        assert_eq!(l.in_order().last().map(|c| c.name.as_str()), Some(DEFAULT_LABEL_CLASS));
        assert!(l.class(&format!("c{}", MAX_LABEL_CLASSES + 1)).is_none() && l.class_mut("c70").is_none());
        l.repoint_missing_fields(&ds);
        assert!(l.classes.iter().all(|c| c.field == "name"));
        // With Default's field gone too (a refresh clears it), they take the first name-like one.
        l.default.field.clear();
        l.classes[0].field = "gone".into();
        l.repoint_missing_fields(&ds);
        assert_eq!(l.classes[0].field, "name");
        // Default on a field that's gone starts again on a name-like one, keeping its own settings.
        (l.enabled, l.default.name, l.default.visible, l.default.where_) = (true, "Rest".into(), false, Some("name = 'x'".into()));
        l.default.field = "gone".into();
        l.restart_default(&ds);
        assert!(!l.enabled);
        assert_eq!(
            (l.default.field.as_str(), l.default.name.as_str(), l.default.visible, l.default.where_.as_deref()),
            ("name", "Rest", false, Some("name = 'x'"))
        );
    }

    #[test]
    fn a_feature_takes_every_class_that_matches() {
        let mut ds = Dataset::new("t", GeometryType::Point, vec![Field::new("pop", FieldType::Integer)]);
        for pop in [5, 50, 500] {
            ds.push(None, vec![Value::Int(pop)]);
        }
        let mut l = Labeling::default_for(&ds);
        let class = |name: &str, w: &str| LabelClass { name: name.into(), where_: Some(w.into()), ..LabelClass::default_for(&ds) };
        l.classes = vec![class("Big", "pop > 100"), class("Medium", "pop > 10"), class("Broken", "nope = 1")];
        let names = |l: &Labeling| -> Vec<Vec<(usize, String)>> {
            let m = LabelMatcher::new(l, &ds);
            (0..3).map(|r| m.classes_of(&ds, r).map(|(i, c)| (i, c.name.clone())).collect()).collect()
        };
        let (big, medium, default) = ((0, "Big".to_string()), (1, "Medium".to_string()), (3, "Default".to_string()));
        assert_eq!(
            names(&l),
            [vec![default.clone()], vec![medium.clone(), default.clone()], vec![big.clone(), medium.clone(), default]],
            "500 is Big, Medium and Default; a clause that doesn't read takes nothing"
        );
        // A Default class with a clause labels only what it matches.
        l.default.where_ = Some("pop = 50".into());
        assert_eq!(names(&l), [vec![], vec![medium.clone(), (3, "Default".to_string())], vec![big, medium]]);
        assert_eq!(l.class("medium").map(|c| c.name.as_str()), Some("Medium"), "names match ASCII case aside");
    }

    #[test]
    fn fmt_num_switches_form_when_it_rounds_up() {
        assert_eq!(fmt_num(0.42), "0.42");
        assert_eq!(fmt_num(42.0), "42");
        assert_eq!(fmt_num(99.994), "99.99");
        assert_eq!(fmt_num(99.995), "100");
        assert_eq!(fmt_num(99.996), "100");
        assert_eq!(fmt_num(9_999.4), "9999");
        assert_eq!(fmt_num(9_999.5), "10K");
        assert_eq!(fmt_num(9_999.6), "10K");
        assert_eq!(fmt_num(35_000.0), "35K");
        assert_eq!(fmt_num(999_400.0), "999K");
        assert_eq!(fmt_num(999_500.0), "1.0M");
        assert_eq!(fmt_num(999_600.0), "1.0M");
        assert_eq!(fmt_num(1_000_000.0), "1.0M");
        assert_eq!(fmt_num(1_234_567.0), "1.2M");
        assert_eq!(fmt_num(999_940_000.0), "999.9M");
        assert_eq!(fmt_num(999_950_000.0), "1.0B");
        assert_eq!(fmt_num(999_960_000.0), "1.0B");
        assert_eq!(fmt_num(-999_600.0), "-1.0M");
    }
    #[test]
    fn the_legend_lists_only_classes_kept_features_have() {
        let mut d = Dataset::new("t", GeometryType::Polygon, vec![Field::new("g", FieldType::Text)]);
        for g in ["a", "b", "a", "z"] {
            d.push(None, vec![Value::Text(g.into())]);
        }
        let s = |c| Symbol::default_for(GeometryType::Polygon, c);
        // "c" is no feature's value; "z" matches no class.
        let r = Renderer::Unique {
            field: "g".into(),
            classes: vec![("a".into(), s(0)), ("b".into(), s(1)), ("c".into(), s(2))],
            other: s(3),
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        let labels = |rows: &[bool]| r.legend_for(&d, rows).into_iter().map(|e| e.label).collect::<Vec<_>>();
        assert_eq!(labels(&[]), ["a", "b", "<all other values>"]);
        assert_eq!(labels(&[true, false, true, false]), ["a"], "<all other values> only when used");
        assert_eq!(labels(&[false, true]), ["a", "b", "<all other values>"], "rows past the end (a, z) count as kept");
        assert_eq!(labels(&[false, false, false, true]), ["<all other values>"]);
        assert!(labels(&[false; 4]).is_empty());
        // The full legend is unchanged.
        assert_eq!(r.legend().len(), 4);
        // A class listed twice: the first matches, and the scan still stops once all are seen.
        let twice = Renderer::Unique {
            field: "g".into(),
            classes: vec![("a".into(), s(0)), ("a".into(), s(1)), ("b".into(), s(2))],
            other: s(3),
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        let shown = twice.legend_for(&d, &[]);
        assert_eq!(shown.iter().map(|e| e.label.as_str()).collect::<Vec<_>>(), ["a", "b", "<all other values>"]);
        assert_eq!(shown[0].symbol, s(0));
        // A field the data no longer has: every feature is "other".
        let gone = Renderer::Unique {
            field: "nope".into(),
            classes: vec![("a".into(), s(0))],
            other: s(3),
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        assert_eq!(gone.legend_for(&d, &[]).len(), 1);
        // The fallback row is marked as such, whatever a class is called.
        let named = Renderer::Unique {
            field: "g".into(),
            classes: vec![("a".into(), s(0)), (OTHER_VALUES.into(), s(1))],
            other: s(3),
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        let mut d2 = d.clone();
        d2.push(None, vec![Value::Text(OTHER_VALUES.into())]);
        let rows = named.legend_for(&d2, &[]);
        assert_eq!(
            rows.iter().map(|e| (e.label.as_str(), e.fallback)).collect::<Vec<_>>(),
            [(OTHER_VALUES, false), ("a", false), (OTHER_VALUES, true)]
        );
        // Other renderers list their classes as they are.
        assert_eq!(Renderer::Single(s(0)).legend_for(&d, &[false; 4]), Vec::new());
    }

    #[test]
    fn a_transparent_fallback_is_left_out_of_the_legend() {
        let mut d = Dataset::new("t", GeometryType::Polygon, vec![Field::new("g", FieldType::Text)]);
        for g in ["a", "z"] {
            d.push(None, vec![Value::Text(g.into())]);
        }
        let s = |c| Symbol::default_for(GeometryType::Polygon, c);
        let mut other = s(3);
        other.fill = other.fill.with_alpha(0);
        other.stroke = other.stroke.with_alpha(0);
        let r = Renderer::Unique {
            field: "g".into(),
            classes: vec![("a".into(), s(0))],
            other,
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        let labels = |r: &Renderer, rows: &[bool]| r.legend_for(&d, rows).into_iter().map(|e| e.label).collect::<Vec<_>>();
        assert_eq!(labels(&r, &[]), ["a"], "z falls in the invisible fallback");
        assert!(labels(&r, &[false, true]).is_empty(), "only the invisible fallback is used");
        // A visible stroke alone still stands for the features.
        let mut stroked = other;
        stroked.stroke = stroked.stroke.with_alpha(255);
        let r2 = Renderer::Unique {
            field: "g".into(),
            classes: vec![("a".into(), s(0))],
            other: stroked,
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        assert_eq!(labels(&r2, &[]), ["a", OTHER_VALUES]);
        // A line's fill draws nothing: a fallback with only a fill is invisible on lines.
        let mut lines = Dataset::new("l", GeometryType::Polyline, vec![Field::new("g", FieldType::Text)]);
        lines.push(None, vec![Value::Text("z".into())]);
        let mut filled = other;
        filled.fill = filled.fill.with_alpha(255);
        let r3 = Renderer::Unique {
            field: "g".into(),
            classes: vec![("a".into(), s(0))],
            other: filled,
            ramp: Ramp::Ember,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        assert!(r3.legend_for(&lines, &[]).is_empty());
        assert_eq!(labels(&r3, &[]), ["a", OTHER_VALUES], "a polygon fill still shows");
        // The full legend (the symbology editor's list) keeps it.
        assert_eq!(r.legend().len(), 2);
    }

    #[test]
    fn categorical_children_sort_case_insensitively_without_changing_symbols() {
        let names = ["Zulu", "alpha", "Bravo", "ALPHA", "éclair", "École"];
        let mut data = Dataset::new("categories", GeometryType::Point, vec![Field::new("name", FieldType::Text)]);
        let classes: Vec<_> = names
            .iter()
            .enumerate()
            .map(|(i, name)| {
                data.push(None, vec![Value::Text((*name).into())]);
                ((*name).into(), Symbol::default_for(GeometryType::Point, i as u32))
            })
            .collect();
        let renderer = Renderer::Unique {
            field: "name".into(),
            classes: classes.clone(),
            other: Symbol::default_for(GeometryType::Point, 99),
            ramp: Ramp::Ember,
            class_labels: BTreeMap::new(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        };
        let legend = renderer.legend();
        assert_eq!(
            legend.iter().map(|e| e.label.as_str()).collect::<Vec<_>>(),
            ["alpha", "ALPHA", "Bravo", "Zulu", "éclair", "École", "<all other values>"]
        );
        for (i, (name, symbol)) in classes.iter().enumerate() {
            assert_eq!(legend.iter().find(|e| &e.label == name).unwrap().symbol, *symbol);
            assert_eq!(renderer.symbol_for(&data, i), *symbol);
        }
        let filtered = renderer.legend_for(&data, &[true, false, true, true, false, false]);
        assert_eq!(filtered.iter().map(|e| e.label.as_str()).collect::<Vec<_>>(), ["ALPHA", "Bravo", "Zulu"]);
        for entry in &filtered {
            assert_eq!(entry.symbol, classes.iter().find(|(name, _)| name == &entry.label).unwrap().1);
            assert!(!entry.fallback);
        }
        data.push(None, vec![Value::Text("unclassified".into())]);
        assert_eq!(renderer.legend_for(&data, &[]), legend);
    }

    #[test]
    fn breaks() {
        let v: Vec<f64> = vec![1.0, 2.0, 3.0, 10.0, 11.0, 12.0, 50.0, 51.0, 52.0];
        let j = class_breaks(&v, 3, ClassMethod::NaturalBreaks);
        assert_eq!(j, vec![3.0, 12.0, 52.0]);
        assert_eq!(class_breaks(&v, 3, ClassMethod::EqualInterval).len(), 3);
        assert_eq!(class_breaks(&[], 3, ClassMethod::Quantile), Vec::<f64>::new());
        assert_eq!(class_breaks(&[5.0, 5.0], 4, ClassMethod::NaturalBreaks), vec![5.0]);
    }

    fn close(a: &[f64], b: &[f64]) -> bool {
        a.len() == b.len() && a.iter().zip(b).all(|(x, y)| (x - y).abs() < 1e-9 * y.abs().max(1.0))
    }

    #[test]
    fn geometric_interval_breaks_grow_by_one_ratio() {
        // Positive values: each bound is the one before times (hi / lo)^(1/k).
        let v = [1.0, 5.0, 40.0, 300.0, 1000.0];
        let b = class_breaks(&v, 3, ClassMethod::GeometricInterval);
        assert!(close(&b, &[10.0, 100.0, 1000.0]), "{b:?}");
        // From zero (or below), the values are shifted so the minimum sits at a hundredth of the
        // range: the widths still grow by one ratio, and the last bound is the maximum.
        let b = class_breaks(&[-50.0, 0.0, 50.0], 2, ClassMethod::GeometricInterval);
        assert!(close(&b, &[-51.0 + 101f64.sqrt(), 50.0]), "{b:?}");
        let b = class_breaks(&[0.0, 100.0], 4, ClassMethod::GeometricInterval);
        let widths: Vec<f64> = std::iter::once(b[0]).chain(b.windows(2).map(|w| w[1] - w[0])).collect();
        assert!(widths.windows(2).all(|w| w[1] > w[0]), "{b:?}");
        assert_eq!(b.len(), 4);
        assert_eq!(b.last(), Some(&100.0));
        // Far from zero the shift is not added and taken away again, so it can't round off.
        let b = class_breaks(&[-1e16, -9_999_999_999_999_998.0], 2, ClassMethod::GeometricInterval);
        assert!(b.iter().all(|v| v.is_finite()), "{b:?}");
        assert_eq!(b.last(), Some(&-9_999_999_999_999_998.0));
        // Near the largest float nothing overflows: the bounds stay finite and in order.
        for v in [[1e308, 1.1e308], [-1e308, 1e308], [1e-308, 1e308]] {
            let b = class_breaks(&v, 2, ClassMethod::GeometricInterval);
            assert!(b.len() == 2 && b.iter().all(|x| x.is_finite()) && b[0] >= v[0] && b[0] < b[1], "{v:?}: {b:?}");
        }
    }

    #[test]
    fn standard_deviation_breaks_are_one_deviation_wide_about_the_mean() {
        // 0..=100: mean 50, population deviation sqrt(850).
        let v: Vec<f64> = (0..=100).map(f64::from).collect();
        let sd = 850f64.sqrt();
        // An even count puts a bound on the mean; an odd one centres a class on it.
        let b = class_breaks(&v, 4, ClassMethod::StandardDeviation);
        assert!(close(&b, &[50.0 - sd, 50.0, 50.0 + sd, 100.0]), "{b:?}");
        let b = class_breaks(&v, 3, ClassMethod::StandardDeviation);
        assert!(close(&b, &[50.0 - sd / 2.0, 50.0 + sd / 2.0, 100.0]), "{b:?}");
        // Bounds past the data are dropped rather than leaving empty classes: 8 classes of one
        // deviation would reach ±4 deviations, but the data spans less than ±2.
        let b = class_breaks(&v, 8, ClassMethod::StandardDeviation);
        assert!(close(&b, &[50.0 - sd, 50.0, 50.0 + sd, 100.0]), "{b:?}");
        // A bound with no value above the one before it goes too: mean 4, deviation sqrt(24), so
        // (4, 4 + sqrt(24)] would hold nothing between the zeros and the tens.
        let b = class_breaks(&[0.0, 0.0, 0.0, 10.0, 10.0], 4, ClassMethod::StandardDeviation);
        assert!(close(&b, &[4.0, 10.0]), "{b:?}");
        // Large values: the squared deviations would overflow without scaling.
        let b = class_breaks(&[1e160, 2e160], 2, ClassMethod::StandardDeviation);
        assert!(close(&b, &[1.5e160, 2e160]), "{b:?}");
        let b = class_breaks(&[-1e308, 1e308], 2, ClassMethod::StandardDeviation);
        assert!(close(&b, &[0.0, 1e308]), "{b:?}");
    }

    #[test]
    fn close_values_keep_their_classes() {
        // Bounds closer than f64::EPSILON in absolute terms are still distinct when the values
        // themselves are that small.
        for m in ClassMethod::ALL {
            let b = class_breaks(&[0.0, 1e-18], 2, m);
            assert!(b.len() == 2 && b[0] >= 0.0 && b[0] < b[1], "{m:?}: {b:?}");
        }
        // And close values far from zero keep theirs too.
        let b = class_breaks(&[1e16, 1e16 + 2.0], 2, ClassMethod::Quantile);
        assert_eq!(b, vec![1e16, 1e16 + 2.0]);
    }

    #[test]
    fn every_method_is_listed_named_and_read_back() {
        for m in ClassMethod::ALL {
            let name = format!("{m:?}");
            let camel = format!("{}{}", name[..1].to_ascii_lowercase(), &name[1..]);
            assert_eq!(ClassMethod::from_name(&camel), Some(m), "{camel}");
            assert_eq!(ClassMethod::from_name(&m.label().replace(" (Jenks)", "")), Some(m), "{}", m.label());
        }
        assert_eq!(ClassMethod::from_name("stddev"), Some(ClassMethod::StandardDeviation));
        assert_eq!(ClassMethod::from_name("geometric"), Some(ClassMethod::GeometricInterval));
    }

    #[test]
    fn graduated_symbols_by_value() {
        let mut d = Dataset::new("t", GeometryType::Polygon, vec![Field::new("v", FieldType::Double)]);
        for v in [1.0, 2.0, 50.0, 60.0] {
            d.push(None, vec![Value::Float(v)]);
        }
        d.push(None, vec![Value::Null]);
        let r =
            Renderer::graduated(&d, &[], "v", 2, ClassMethod::NaturalBreaks, Ramp::Ember, Symbol::default_for(GeometryType::Polygon, 0))
                .unwrap();
        assert_ne!(r.symbol_for(&d, 0).fill, r.symbol_for(&d, 3).fill);
        assert_eq!(r.legend().len(), 2);
        let _ = r.symbol_for(&d, 4);
        let _ = r.symbol_for(&d, 999);
        assert!(
            Renderer::graduated(&d, &[], "nope", 2, ClassMethod::Quantile, Ramp::Ember, Symbol::default_for(GeometryType::Polygon, 0))
                .is_err()
        );
    }

    #[test]
    fn classes_come_from_the_kept_rows() {
        let mut d = Dataset::new("t", GeometryType::Polygon, vec![Field::new("v", FieldType::Double)]);
        for v in [1.0, 2.0, 3.0, 1000.0] {
            d.push(None, vec![Value::Float(v)]);
        }
        let base = Symbol::default_for(GeometryType::Polygon, 0);
        let rows = [true, true, true, false];
        let Ok(Renderer::Graduated { breaks, min, .. }) =
            Renderer::graduated(&d, &rows, "v", 2, ClassMethod::EqualInterval, Ramp::Ember, base)
        else {
            panic!("graduated renderer expected")
        };
        assert_eq!(breaks.last().copied(), Some(3.0));
        assert_eq!(min, 1.0);
        // A short row list keeps the rows past its end.
        let Ok(Renderer::Graduated { breaks, .. }) =
            Renderer::graduated(&d, &[false], "v", 2, ClassMethod::EqualInterval, Ramp::Ember, base)
        else {
            panic!("graduated renderer expected")
        };
        assert_eq!(breaks.last().copied(), Some(1000.0));
        assert!(Renderer::graduated(&d, &[false; 4], "v", 2, ClassMethod::Quantile, Ramp::Ember, base).is_err());
        let Ok(Renderer::Unique { classes, .. }) = Renderer::unique(&d, &[false, true, false, true], "v", Ramp::Harbour, base) else {
            panic!("unique renderer expected")
        };
        let keys: Vec<&str> = classes.iter().map(|(k, _)| k.as_str()).collect();
        assert_eq!(keys, vec!["1000", "2"]);
    }

    fn unique(classes: &[(&str, Symbol)], other: Symbol, ramp: Ramp) -> Renderer {
        Renderer::Unique {
            field: "g".into(),
            classes: classes.iter().map(|(k, s)| (k.to_string(), *s)).collect(),
            other,
            ramp,
            class_labels: Default::default(),
            other_label: None,
            class_strokes: Default::default(),
            other_strokes: Vec::new(),
        }
    }

    fn graduated(breaks: &[f64], symbols: &[Symbol], ramp: Ramp) -> Renderer {
        Renderer::Graduated {
            field: "v".into(),
            breaks: breaks.to_vec(),
            symbols: symbols.to_vec(),
            ramp,
            method: ClassMethod::Quantile,
            min: 0.0,
            class_labels: Default::default(),
            class_strokes: Default::default(),
        }
    }

    fn labels_of(r: &Renderer) -> Vec<String> {
        r.legend().into_iter().map(|e| e.label).collect()
    }

    #[test]
    fn a_class_takes_its_own_colour_outline_and_label() {
        let g = GeometryType::Polygon;
        let s = |c| Symbol::default_for(g, c);
        let (red, blue) = (Rgba::rgb(0xC0, 0x30, 0x20), Rgba::rgb(0, 0, 0xFF));
        let mut r = unique(&[("a", s(0)), ("b", s(1))], s(3), Ramp::Ember);
        let style =
            |color, outline, label: Option<&str>| ClassStyle { color, outline, label: label.map(str::to_string), ..Default::default() };
        let e = r.set_class_style(&ClassRef::Value("b".into()), &style(Some(red), None, Some("  Bee ")), g).unwrap();
        assert_eq!(e.label, "Bee");
        assert_eq!((e.symbol.fill, e.symbol.stroke, e.fallback), (red, red.shade(0.6), false));
        assert_eq!(labels_of(&r), ["a", "Bee", OTHER_VALUES]);
        // The fallback class, with an outline alone: the fill stays.
        let e = r.set_class_style(&ClassRef::Other, &style(None, Some(blue), Some("Others")), g).unwrap();
        assert!(e.fallback);
        assert_eq!((e.symbol.stroke, e.symbol.fill), (blue, s(3).fill));
        // The legend of what is drawn shows the labels too.
        let mut d = Dataset::new("t", g, vec![Field::new("g", FieldType::Text)]);
        for v in ["b", "z"] {
            d.push(None, vec![Value::Text(v.into())]);
        }
        assert_eq!(r.legend_for(&d, &[]).into_iter().map(|e| e.label).collect::<Vec<_>>(), ["Bee", "Others"]);
        // A label that is the value itself (or <all other values>) is no label of its own.
        r.set_class_style(&ClassRef::Value("b".into()), &style(None, None, Some("b")), g).unwrap();
        assert!(matches!(&r, Renderer::Unique { class_labels, .. } if class_labels.is_empty()));
        r.set_class_style(&ClassRef::Value("b".into()), &style(None, None, Some("Bee")), g).unwrap();
        r.set_class_style(&ClassRef::Other, &style(None, None, Some(OTHER_VALUES)), g).unwrap();
        assert!(matches!(&r, Renderer::Unique { other_label: None, .. }));
        r.set_class_style(&ClassRef::Other, &style(None, None, Some("Others")), g).unwrap();
        // An empty (or blank) label goes back to the value.
        r.set_class_style(&ClassRef::Value("b".into()), &style(None, None, Some("")), g).unwrap();
        r.set_class_style(&ClassRef::Other, &style(None, None, Some("  ")), g).unwrap();
        assert_eq!(labels_of(&r), ["a", "b", OTHER_VALUES]);
        // A class that isn't there, or named the wrong way, is refused and changes nothing.
        let before = r.clone();
        assert!(r.set_class_style(&ClassRef::Value("nope".into()), &style(Some(red), None, None), g).is_err());
        assert!(r.set_class_style(&ClassRef::Index(0), &style(Some(red), None, None), g).is_err());
        assert_eq!(r, before);
        assert!(Renderer::Single(s(0)).set_class_style(&ClassRef::Other, &style(Some(red), None, None), g).is_err());
        // A line class takes the colour as its line colour.
        let line = Symbol::default_for(GeometryType::Polyline, 0);
        let mut lines = unique(&[("a", line)], line, Ramp::Ember);
        let e = lines.set_class_style(&ClassRef::Value("a".into()), &style(Some(red), None, None), GeometryType::Polyline).unwrap();
        assert_eq!(e.symbol.stroke, red);
        // Graduated Colors: by number, and the label replaces the range.
        let mut gr = graduated(&[10.0, 20.0], &[s(0), s(1)], Ramp::Ember);
        let e = gr.set_class_style(&ClassRef::Index(1), &style(Some(red), None, Some("High")), g).unwrap();
        assert_eq!((e.label.as_str(), e.symbol.fill, e.symbol.stroke), ("High", red, red.shade(0.6)));
        assert_eq!(labels_of(&gr), ["0 – 10", "High"]);
        gr.set_class_style(&ClassRef::Index(0), &style(None, None, Some("0 – 10")), g).unwrap();
        assert!(matches!(&gr, Renderer::Graduated { class_labels, .. } if !class_labels.contains_key(&0)), "the range itself is no label");
        assert!(gr.set_class_style(&ClassRef::Index(2), &style(None, None, Some("x")), g).is_err());
        assert!(gr.set_class_style(&ClassRef::Other, &style(None, None, Some("x")), g).is_err());
        // A very long label is cut.
        let e = gr.set_class_style(&ClassRef::Index(0), &style(None, None, Some(&"x".repeat(500))), g).unwrap();
        assert_eq!(e.label.chars().count(), MAX_LABEL);
        // A label is one line.
        let e = gr.set_class_style(&ClassRef::Index(0), &style(None, None, Some("Low\nincome\t")), g).unwrap();
        assert_eq!(e.label, "Low income");
        // A cut that lands on a space doesn't leave it at the end.
        let long = format!("{} {}", "x".repeat(MAX_LABEL - 1), "y".repeat(10));
        let e = gr.set_class_style(&ClassRef::Index(0), &style(None, None, Some(&long)), g).unwrap();
        assert_eq!(e.label, "x".repeat(MAX_LABEL - 1));
    }

    #[test]
    fn class_labels_are_saved_and_older_renderers_still_load() {
        let g = GeometryType::Point;
        let s = |c| Symbol::default_for(g, c);
        // A renderer nobody edited saves as before #314, so older versions still read it.
        let mut r = unique(&[("a", s(0))], s(1), Ramp::Ember);
        let j = serde_json::to_string(&r).unwrap();
        assert!(!j.contains("class_labels") && !j.contains("other_label"), "{j}");
        assert_eq!(serde_json::from_str::<Renderer>(&j).unwrap(), r);
        r.set_class_style(&ClassRef::Value("a".into()), &ClassStyle { label: Some("A".into()), ..Default::default() }, g).unwrap();
        r.set_class_style(&ClassRef::Other, &ClassStyle { label: Some("Rest".into()), ..Default::default() }, g).unwrap();
        assert_eq!(serde_json::from_str::<Renderer>(&serde_json::to_string(&r).unwrap()).unwrap(), r);
        // Class numbers round-trip as JSON object keys.
        let mut gr = graduated(&[1.0, 2.0], &[s(0), s(1)], Ramp::Ember);
        gr.set_class_style(&ClassRef::Index(1), &ClassStyle { label: Some("Two".into()), ..Default::default() }, g).unwrap();
        assert_eq!(serde_json::from_str::<Renderer>(&serde_json::to_string(&gr).unwrap()).unwrap(), gr);
    }

    #[test]
    fn applying_the_symbology_again_keeps_hand_edits() {
        let g = GeometryType::Polygon;
        let base = Symbol::default_for(g, 0);
        // Classes coloured by their scheme, as Renderer::unique and Renderer::graduated make them.
        let ramped = |keys: &[&str], ramp: Ramp| {
            let n = keys.len();
            let classes: Vec<(&str, Symbol)> = keys.iter().enumerate().map(|(k, v)| (*v, base.with_fill(ramp.pick(k, n), g))).collect();
            unique(&classes, base.with_fill(OTHER_FILL, g), ramp)
        };
        let (red, blue) = (Rgba::rgb(0xC0, 0x30, 0x20), Rgba::rgb(0, 0, 0xFF));
        let edit = |r: &mut Renderer, c: ClassRef, color: Option<Rgba>, outline: Option<Rgba>, label: Option<&str>| {
            r.set_class_style(&c, &ClassStyle { color, outline, label: label.map(str::to_string), ..Default::default() }, g).unwrap();
        };
        let mut old = ramped(&["a", "b", "c"], Ramp::Ember);
        edit(&mut old, ClassRef::Value("b".into()), Some(red), None, Some("Bee"));
        edit(&mut old, ClassRef::Value("c".into()), None, Some(blue), None);
        edit(&mut old, ClassRef::Other, Some(red), None, Some("Rest"));
        // Same field and scheme, "a" gone and "d" new: only the hand edits carry over. "c" keeps
        // its outline but takes the scheme's colour at its new place, not the one it had.
        let fresh = ramped(&["b", "c", "d"], Ramp::Ember);
        let mut again = fresh.clone();
        again.carry_edits_from(&old, g);
        let (Renderer::Unique { classes, other, .. }, Renderer::Unique { classes: fc, .. }) = (&again, &fresh) else {
            panic!("unique renderers expected")
        };
        assert_eq!((classes[0].1.fill, classes[0].1.stroke), (red, red.shade(0.6)), "b keeps its colour");
        assert_eq!((classes[1].1.fill, classes[1].1.stroke), (fc[1].1.fill, blue), "c keeps its outline only");
        assert_eq!(classes[2].1, fc[2].1, "d is new");
        assert_eq!((other.fill, other.stroke), (red, red.shade(0.6)));
        assert_eq!(labels_of(&again), ["Bee", "c", "d", "Rest"]);
        // A polygon class's own transparency, and an outline that differs only in it, carry over too.
        let mut tinted = ramped(&["a"], Ramp::Ember);
        if let Renderer::Unique { classes, .. } = &mut tinted {
            classes[0].1.fill = red.with_alpha(80);
            classes[0].1.stroke = red.shade(0.6).with_alpha(100);
        }
        let mut kept = ramped(&["a"], Ramp::Ember);
        kept.carry_edits_from(&tinted, g);
        let (Renderer::Unique { classes: kc, .. }, Renderer::Unique { classes: tc, .. }) = (&kept, &tinted) else {
            panic!("unique renderers expected")
        };
        assert_eq!((kc[0].1.fill, kc[0].1.stroke), (tc[0].1.fill, tc[0].1.stroke));
        // An unedited renderer applied again is the fresh one.
        let mut plain = fresh.clone();
        plain.carry_edits_from(&ramped(&["b", "c"], Ramp::Ember), g);
        assert_eq!(plain, fresh);
        // Another scheme recolours but keeps the labels; another field starts fresh.
        let fresh = ramped(&["b"], Ramp::Harbour);
        let mut recoloured = fresh.clone();
        recoloured.carry_edits_from(&old, g);
        let (Renderer::Unique { classes, other, .. }, Renderer::Unique { classes: fc, other: fo, .. }) = (&recoloured, &fresh) else {
            panic!("unique renderers expected")
        };
        assert_eq!((classes, other), (fc, fo));
        assert_eq!(labels_of(&recoloured), ["Bee", "Rest"]);
        let mut other_field = ramped(&["b"], Ramp::Ember);
        if let Renderer::Unique { field, .. } = &mut other_field {
            *field = "h".into();
        }
        let fresh = other_field.clone();
        other_field.carry_edits_from(&old, g);
        assert_eq!(other_field, fresh);
        // Graduated Colors: edits by number while the count and scheme stay; labels while the ranges do.
        let ramped = |breaks: &[f64], ramp: Ramp| {
            let n = breaks.len();
            graduated(breaks, &(0..n).map(|i| base.with_fill(ramp.pick(i, n), g)).collect::<Vec<_>>(), ramp)
        };
        let mut gold = ramped(&[10.0, 20.0], Ramp::Ember);
        edit(&mut gold, ClassRef::Index(0), Some(red), None, Some("Low"));
        let mut same = ramped(&[10.0, 20.0], Ramp::Ember);
        same.carry_edits_from(&gold, g);
        assert_eq!(same, gold);
        let fresh = ramped(&[12.0, 20.0], Ramp::Ember);
        let mut moved = fresh.clone();
        moved.carry_edits_from(&gold, g);
        let (Renderer::Graduated { symbols, .. }, Renderer::Graduated { symbols: fs, .. }) = (&moved, &fresh) else {
            panic!("graduated renderers expected")
        };
        assert_eq!((symbols[0], symbols[1]), (fs[0], fs[1]), "the range moved: its colour goes");
        assert_eq!(labels_of(&moved), ["0 – 12", "12 – 20"], "and its label too");
        let fresh = ramped(&[10.0, 15.0, 20.0], Ramp::Ember);
        let mut more = fresh.clone();
        more.carry_edits_from(&gold, g);
        assert_eq!(more, fresh, "another number of classes starts fresh");
    }
}
